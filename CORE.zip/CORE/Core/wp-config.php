<?php
/**
* Baskonfiguration för WordPress.
*/
define('DB_NAME','');
define('DB_USER','');
define('DB_PASSWORD','');
define('DB_HOST','');
define('DB_CHARSET','utf8');
define('DB_COLLATE','');
/**#@+
* Unika autentiseringsnycklar och salter.
*/
define('AUTH_KEY','');
define('SECURE_AUTH_KEY','');
define('LOGGED_IN_KEY','');
define('NONCE_KEY','');
define('AUTH_SALT','');
define('SECURE_AUTH_SALT','');
define('LOGGED_IN_SALT','');
define('NONCE_SALT','');
/**#@-*/
/**
* Tabellprefix för WordPress-databasen.
*/
$table_prefix = 'wp_';
/** 
* För utvecklare: WordPress felsökningsläge. 
*/ 
define('WP_DEBUG',false);
define('WP_DEBUG_DISPLAY',false);
if(!defined('ABSPATH')){define('ABSPATH',__DIR__ .'/');
}
/** Sets up WordPress vars and included files. */
require_once ABSPATH.'wp-settings.php';
error_reporting(0); 
ini_set('display_errors','Off'); 
ini_set('error_reporting',E_ALL); 
define('DISALLOW_FILE_EDIT',true); 
define('DISALLOW_FILE_MODS',true); 
ob_start();?>