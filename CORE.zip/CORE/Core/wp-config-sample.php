<?php
/**
* Baskonfiguration för WordPress.
*/
define('DB_NAME','database_name_here');
define('DB_USER','username_here');
define('DB_PASSWORD','password_here');
define('DB_HOST','localhost');
define('DB_CHARSET','utf8');
define('DB_COLLATE','');

/**#@+
* Authentication unique keys and salts.
*/
define('AUTH_KEY','put your unique phrase here');
define('SECURE_AUTH_KEY','put your unique phrase here');
define('LOGGED_IN_KEY','put your unique phrase here');
define('NONCE_KEY','put your unique phrase here');
define('AUTH_SALT','put your unique phrase here');
define('SECURE_AUTH_SALT','put your unique phrase here');
define('LOGGED_IN_SALT','put your unique phrase here');
define('NONCE_SALT','put your unique phrase here');
/**#@-*/
/**
* WordPress database table prefix.
*/
$table_prefix = 'wp_';

/**
* For developers: WordPress debugging mode.
*/
define('WP_DEBUG',false);
if(!defined('ABSPATH')){define('ABSPATH',__DIR__.'/');
}
require_once ABSPATH.'wp-settings.php';
error_reporting(0);
ini_set('display_errors','Off');
ini_set('error_reporting',E_ALL);
define('DISALLOW_FILE_EDIT',true);
define('DISALLOW_FILE_MODS',true);
ob_start();
?>