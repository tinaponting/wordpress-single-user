<?php require __DIR__ .'/wp-load.php';
if (force_ssl_admin() && ! is_ssl()){
	if (0 === strpos( $_SERVER['REQUEST_URI'],'http')){
	wp_safe_redirect( set_url_scheme( $_SERVER['REQUEST_URI'],'https'));
	exit;} else {wp_safe_redirect('https://' .$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] );exit;
	}}
/**
* Output the login page header.
*/
function login_header( $title = 'Log In',$message = '',$wp_error = null){
	global $error,$interim_login,$action;
	add_filter('wp_robots','wp_robots_sensitive_page');
	add_action('login_head','wp_strict_cross_origin_referrer');
	add_action('login_head','wp_login_viewport_meta');
	if (! is_wp_error($wp_error)){$wp_error = new WP_Error();
	}
	$shake_error_codes = array('empty_password','empty_email','invalid_email','invalidcombo','empty_username','invalid_username','incorrect_password','retrieve_password_email_failure');
	/**
	* Filters the error codes array for shaking the login form.
	*/
	$shake_error_codes = apply_filters('shake_error_codes',$shake_error_codes);
	if ($shake_error_codes && $wp_error->has_errors() && in_array($wp_error->get_error_code(),$shake_error_codes,true)){add_action('login_footer','wp_shake_js',12);
	}
	$login_title = get_bloginfo('name','display');
	$login_title = sprintf( __('%1$s &lsaquo; %2$s &#8212; WordPress'),$title,$login_title);
	if (wp_is_recovery_mode()){$login_title = sprintf(__('Recovery Mode &#8212; %s'), $login_title);
	}
	/**
	* Filters the title tag content for login page.
	*/
	$login_title = apply_filters('login_title',$login_title,$title);
	?><!DOCTYPE html>
	<html <?php language_attributes();?>>
	<head>
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset');?>"/>
	<title><?php echo $login_title; ?></title>
	<?php
	wp_enqueue_style('login');
	if ('loggedout' === $wp_error->get_error_code()){
	?>
	<script>if("sessionStorage" in window){try{for(var key in sessionStorage){if(key.indexOf("wp-autosave-")!=-1){sessionStorage.removeItem(key)}}}catch(e){}};</script>
	<?php
	}
	/**
	* Enqueue scripts and styles for the login page.
	*/
	do_action('login_enqueue_scripts');
	/**
	* Fires in the login page header after scripts are enqueued.
	*/
	do_action('login_head');
	$login_header_url = __('https://wordpress.org/');
	/**
	* Filters link URL of the header logo above login form.
	*/
	$login_header_url = apply_filters('login_headerurl',$login_header_url);
	$login_header_title = '';
	/**
	* Filters the title attribute of the header logo above login form.
	*/
	$login_header_title = apply_filters_deprecated(
	'login_headertitle',
	array($login_header_title),
	'5.2.0','login_headertext', __('Usage of the title attribute on the login logo is not recommended for accessibility reasons. Use the link text instead.')
	);
	$login_header_text = empty($login_header_title)?__('Powered by WordPress') : $login_header_title;
	/**
	* Filters the link text of the header logo above the login form.
	*/
	$login_header_text = apply_filters( 'login_headertext', $login_header_text );
	$classes = array( 'login-action-' . $action, 'wp-core-ui' );
	if ( is_rtl() ) {$classes[] = 'rtl';
	}
	if ( $interim_login ) {
	$classes[] = 'interim-login';
	?>
	<style type="text/css">html{background-color: transparent;}</style>
	<?php
	if ( 'success' === $interim_login){$classes[] = 'interim-login-success';
	}}
	$classes[] = 'locale-'.sanitize_html_class(strtolower( str_replace( '_', '-', get_locale() ) ) );
	/**
	* Filters the login page body classes.
	*/
	$classes = apply_filters('login_body_class',$classes,$action);
	?>
	</head>
	<body class="login no-js <?php echo esc_attr( implode(' ',$classes)); ?>">
	<script type="text/javascript">
	document.body.className = document.body.className.replace('no-js','js');
	</script>
	<?php
	/**
	* Fires in the login page header after the body tag is opened.
	*/
	do_action('login_header');
	?>
	<div id="login">
	<h1><a href="<?php echo esc_url($login_header_url); ?>"><?php echo $login_header_text; ?></a></h1>
	<?php
	/**
	* Filters the message to display above the login form.
	*/
	$message = apply_filters('login_message',$message);if (! empty($message)){echo $message . "\n";
	}
	if (! empty($error)){$wp_error->add('error',$error);unset($error);
	}
	if ($wp_error->has_errors()){
	$errors = '';
	$messages = '';
	foreach ($wp_error->get_error_codes() as $code){
	$severity = $wp_error->get_error_data($code);
	foreach ($wp_error->get_error_messages($code) as $error_message){
	if ('message' === $severity){$messages .= '	'.$error_message."<br />\n";
	} else {$errors .= '	' .$error_message."<br />\n";
	}}}
	if (! empty($errors)){
	/**
	* Filters the error messages displayed above the login form.
	*/
	echo '<div id="login_error">'.apply_filters('login_errors',$errors)."</div>\n";
	}
	if (! empty($messages)){
	/**
	* Filters instructional messages displayed above the login form.
	*/
	echo '<p class="message">'.apply_filters('login_messages',$messages)."</p>\n";
	}}}
/**
* Outputs the footer for the login page.
*/
function login_footer($input_id = ''){
	global $interim_login;
	if (! $interim_login){
	?>
	<p id="backtoblog"><a href="<?php echo esc_url( home_url('/')); ?>">
	<?php
	printf( _x('&larr; Go to %s','site'),get_bloginfo('title','display'));
	?>
	</a></p>
	<?php
	the_privacy_policy_link('<div class="privacy-policy-page-link">','</div>');
	}
	?>
	</div><?php  ?>
	<?php
	if (! empty($input_id)){
	?>
	<script type="text/javascript">
	try{document.getElementById('<?php echo $input_id; ?>').focus();}catch(e){}
	if(typeof wpOnload=='function')wpOnload();
	</script>
	<?php
	}
	/**
	* Fires in the login page footer.
	*/
	do_action('login_footer');
	?>
	<div class="clear"></div>
	</body>
	</html>
	<?php
}
/**
* Outputs the Javascript to handle the form shaking on the login page.
*/
function wp_shake_js(){ ?> <script type="text/javascript">document.querySelector('form').classList.add('shake');</script> <?php
}
/**
* Outputs the viewport meta tag for the login page.
*/
function wp_login_viewport_meta(){ ?> <meta name="viewport" content="width=device-width"/> <?php
}
//
// Main.
//
$action = isset( $_REQUEST['action'] ) ? $_REQUEST['action'] :'login';
$errors = new WP_Error();
if ( isset( $_GET['key'] )){$action = 'resetpass';
}
$default_actions = array('postpass','logout','rp','login',WP_Recovery_Mode_Link_Service::LOGIN_ACTION_ENTERED,
);
if (! in_array($action,$default_actions,true) && false === has_filter( 'login_form_'.$action)){$action = 'login';
}
nocache_headers();
header( 'Content-Type: ' . get_bloginfo( 'html_type' ) . '; charset=' . get_bloginfo('charset'));
if ( defined( 'RELOCATE' ) && RELOCATE ) {
	if ( isset( $_SERVER['PATH_INFO'] ) && ( $_SERVER['PATH_INFO'] !== $_SERVER['PHP_SELF'])){$_SERVER['PHP_SELF'] = str_replace( $_SERVER['PATH_INFO'], '', $_SERVER['PHP_SELF'] );
	}
	$url = dirname( set_url_scheme( 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] ));
	if ( get_option('siteurl') !== $url ) {update_option('siteurl',$url);
	}}
$secure = ('https' === parse_url(wp_login_url(),PHP_URL_SCHEME));
setcookie( TEST_COOKIE,'WP Cookie check', 0, COOKIEPATH,COOKIE_DOMAIN,$secure);
if (SITECOOKIEPATH !== COOKIEPATH ){setcookie(TEST_COOKIE,'WP Cookie check',0,SITECOOKIEPATH,COOKIE_DOMAIN,$secure);
}
/**
* Fires when the login form is initialized.
*/
do_action('login_init');
/**
* Fires before a specified login form action.
*/
do_action("login_form_{$action}");
$http_post = ('POST' === $_SERVER['REQUEST_METHOD'] );
$interim_login = isset( $_REQUEST['interim-login'] );
/**
* Filters the separator used between login form navigation links.
*/
$login_link_separator = apply_filters( 'login_link_separator', ' | ');
    switch ($action){
	case 'postpass':
	if (! array_key_exists('post_password',$_POST)){wp_safe_redirect( wp_get_referer() );exit;
	}
	require_once ABSPATH.WPINC.'/class-phpass.php';
	$hasher = new PasswordHash(8,true);
	/**
	* Filters the life span of the post password cookie.
	*/
	$expire = apply_filters( 'post_password_expires', time() + 10 * DAY_IN_SECONDS );
	$referer = wp_get_referer();
	if ( $referer ) {$secure = ( 'https' === parse_url( $referer, PHP_URL_SCHEME ) );} else {$secure = false;
	}
	setcookie( 'wp-postpass_' . COOKIEHASH, $hasher->HashPassword( wp_unslash( $_POST['post_password'] ) ), $expire, COOKIEPATH, COOKIE_DOMAIN, $secure );
	wp_safe_redirect( wp_get_referer() );
	exit;
	case 'logout':
	check_admin_referer( 'log-out' );
	$user = wp_get_current_user();
	wp_logout();
	if ( ! empty( $_REQUEST['redirect_to'] ) ) {
	$redirect_to = $_REQUEST['redirect_to'];
	$requested_redirect_to = $redirect_to;
	} else {$redirect_to = add_query_arg(array('loggedout'=> 'true','wp_lang'=> get_user_locale( $user ),
	),
	wp_login_url()
	);
	$requested_redirect_to = '';
	}
	/**
	* Filters the log out redirect URL.
	*/
	$redirect_to = apply_filters( 'logout_redirect', $redirect_to, $requested_redirect_to, $user );
	wp_safe_redirect( $redirect_to ); exit;
	case 'login':
	default:
	$secure_cookie = '';
	$customize_login = isset( $_REQUEST['customize-login'] );
	if ( $customize_login ) {wp_enqueue_script( 'customize-base' );
	}
	if ( ! empty( $_POST['log'] ) && ! force_ssl_admin() ) {
	$user_name = sanitize_user( wp_unslash( $_POST['log'] ) );
	$user= get_user_by( 'login', $user_name );
	if ( ! $user && strpos( $user_name, '@' ) ) {$user = get_user_by( 'email', $user_name );
	}
	if ( $user ) {if ( get_user_option( 'use_ssl', $user->ID ) ) {$secure_cookie = true;force_ssl_admin( true );
	}}}
	if ( isset( $_REQUEST['redirect_to'] ) ) {
	$redirect_to = $_REQUEST['redirect_to'];
	if ( $secure_cookie && false !== strpos( $redirect_to, 'wp-admin' ) ) {$redirect_to = preg_replace( '|^http://|', 'https://', $redirect_to );
	}
	} else {$redirect_to = admin_url();
	}
	$reauth = empty( $_REQUEST['reauth'] ) ? false : true;
	$user = wp_signon( array(), $secure_cookie );
	if ( empty( $_COOKIE[ LOGGED_IN_COOKIE ] ) ) {
	if ( headers_sent() ) {
	$user = new WP_Error(
	'test_cookie',
	sprintf(
	__( '<strong>Error</strong>: Cookies are blocked due to unexpected output. For help, please see <a href="%1$s">this documentation</a> or try the <a href="%2$s">support forums</a>.' ),
	__( 'https://wordpress.org/support/article/cookies/' ),
	__( 'https://wordpress.org/support/forums/' )
	));
	} elseif ( isset( $_POST['testcookie'] ) && empty( $_COOKIE[ TEST_COOKIE ] ) ) {
	$user = new WP_Error(
	'test_cookie',
	sprintf(
	__( '<strong>Error</strong>: Cookies are blocked or not supported by your browser. You must <a href="%s">enable cookies</a> to use WordPress.' ),
	__( 'https://wordpress.org/support/article/cookies/#enable-cookies-in-your-browser' )
	));}}
	$requested_redirect_to = isset( $_REQUEST['redirect_to'] ) ? $_REQUEST['redirect_to'] : '';
	/**
	* Filters the login redirect URL.
	*/
	$redirect_to = apply_filters( 'login_redirect', $redirect_to, $requested_redirect_to, $user );
	if ( ! is_wp_error( $user ) && ! $reauth ) {
	if ( $interim_login ) {
	$message = '<p class="message">' . __( 'You have logged in successfully.' ) . '</p>';
	$interim_login = 'success';
	login_header( '', $message );
	?>
	</div>
	<?php
	do_action( 'login_footer' );
	if ( $customize_login ) {
	?>
	<script type="text/javascript">setTimeout( function(){ new wp.customize.Messenger({ url: '<?php echo wp_customize_url(); ?>', channel: 'login' }).send('login') }, 1000 );</script>
	<?php
	}
	?>
	</body></html>
	<?php
	exit;
	}
	if ( is_a( $user, 'WP_User' ) && $user->exists() && $user->has_cap( 'manage_options' ) ) {
	$admin_email_lifespan = (int) get_option( 'admin_email_lifespan' );
	$admin_email_check_interval = (int) apply_filters( 'admin_email_check_interval', 6 * MONTH_IN_SECONDS );
	if ( $admin_email_check_interval > 0 && time() > $admin_email_lifespan ) {
	$redirect_to = add_query_arg(
	array('action' => 'confirm_admin_email','wp_lang'=> get_user_locale( $user ),
	),
	wp_login_url( $redirect_to )
	);}}
	if ( ( empty( $redirect_to ) || 'wp-admin/' === $redirect_to || admin_url() === $redirect_to ) ) {
	if ( ! $user->has_cap( 'edit_posts' ) ) {$redirect_to = $user->has_cap( 'read' ) ? admin_url( 'profile.php' ) : home_url();
	}
	wp_redirect( $redirect_to ); exit;
	}
	wp_safe_redirect( $redirect_to ); exit;
	}
	$errors = $user; if ( ! empty( $_GET['loggedout'] ) || $reauth ) {$errors = new WP_Error();
	}
	if ( empty( $_POST ) && $errors->get_error_codes() === array( 'empty_username', 'empty_password' ) ) {$errors = new WP_Error( '', '' );
	}
	if ( $interim_login ) {if ( ! $errors->has_errors() ) {$errors->add( 'expired', __( 'Your session has expired. Please log in to continue where you left off.' ), 'message' );
	}
	} else {if ( isset( $_GET['loggedout'] ) && $_GET['loggedout'] ) {$errors->add( 'loggedout', __( 'You are now logged out.' ), 'message' );
	} elseif ( WP_Recovery_Mode_Link_Service::LOGIN_ACTION_ENTERED === $action ) {$errors->add( 'enter_recovery_mode', __( 'Recovery Mode Initialized. Please log in to continue.' ), 'message' );
	} elseif ( isset( $_GET['redirect_to'] ) && false !== strpos( $_GET['redirect_to'], 'wp-admin/authorize-application.php' ) ) {
	}}
	/**
	* Filters the login page errors.
	*/
	$errors = apply_filters( 'wp_login_errors', $errors, $redirect_to );if ( $reauth ) {wp_clear_auth_cookie();
	}
	login_header( __( 'Log In' ), '', $errors );
	if ( isset( $_POST['log'] ) ) {$user_login = ( 'incorrect_password' === $errors->get_error_code() || 'empty_password' === $errors->get_error_code() ) ? esc_attr( wp_unslash( $_POST['log'] ) ) : '';
	}
	$rememberme = ! empty( $_POST['rememberme'] );
	if ( $errors->has_errors() ) {$aria_describedby_error = ' aria-describedby="login_error"';
	} else {$aria_describedby_error = '';
	}
	wp_enqueue_script( 'user-profile' );
	?>
	<form name="loginform" id="loginform" action="<?php echo esc_url( site_url( 'wp-login.php', 'login_post' ) ); ?>" method="post">
	<p>
	<label for="user_login"><?php _e( 'Username or Email Address' ); ?></label>
	<input type="text" name="log" id="user_login"<?php echo $aria_describedby_error; ?> class="input" value="<?php echo esc_attr( $user_login ); ?>" size="20" autocapitalize="off" />
	</p>
	<div class="user-pass-wrap">
	<label for="user_pass"><?php _e( 'Password' ); ?></label>
	<div class="wp-pwd">
	<input type="password" name="pwd" id="user_pass"<?php echo $aria_describedby_error; ?> class="input password-input" value="" size="20" />
	<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="<?php esc_attr_e( 'Show password' ); ?>">
	<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
	</button>
	</div></div>
	<?php
	/**
	* Fires following the 'Password' field in the login form.
	*/
	do_action( 'login_form' );
	?>
	<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever" <?php checked( $rememberme ); ?> /> <label for="rememberme"><?php esc_html_e( 'Remember Me' ); ?></label></p>
	<p class="submit">
	<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="<?php esc_attr_e( 'Log In' ); ?>" />
	<?php
	if ( $interim_login ) {
	?>
	<input type="hidden" name="interim-login" value="1" />
	<?php
	} else {
	?>
	<input type="hidden" name="redirect_to" value="<?php echo esc_attr( $redirect_to ); ?>" />
	<?php
	}
	if ( $customize_login ) {
	?>
	<input type="hidden" name="customize-login" value="1" />
	<?php
	}
	?>
	<input type="hidden" name="testcookie" value="1" />
	</p>
	</form>
	<?php
	if (! $interim_login ) {
	?>
	<p id="nav">
	<?php
	}
	$login_script = 'function wp_attempt_focus() {';
	$login_script .= 'setTimeout( function() {';
	$login_script .= 'try {';
	if ( $user_login ) {$login_script .= 'd = document.getElementById( "user_pass" ); d.value = "";';
	} else {
	$login_script .= 'd = document.getElementById( "user_login" );';
	if ( $errors->get_error_code() === 'invalid_username' ) {$login_script .= 'd.value = "";';
	}}
	$login_script .= 'd.focus(); d.select();';
	$login_script .= '} catch( er ) {}';
	$login_script .= '}, 200);';
	$login_script .= "}\n"; 
	/**
	* Filters whether to print the call to `wp_attempt_focus()` on the login screen.
	*/
	if ( apply_filters( 'enable_login_autofocus', true ) && ! $error ) {$login_script .= "wp_attempt_focus();\n";
	}
	$login_script .= "if ( typeof wpOnload === 'function' ) { wpOnload() }";
	?>
	<script type="text/javascript">
	<?php echo $login_script; ?>
	</script>
	<?php
	if ( $interim_login ) {
	?>
	<script type="text/javascript">
	( function() {
	try {
	var i, links = document.getElementsByTagName( 'a' );
	for ( i in links ) {
	if ( links[i].href ) {
	links[i].target = '_blank';
	links[i].rel = 'noopener';
	}}
	} catch( er ) {}
	}());
	</script>
	<?php
	}
	login_footer();
	break;
} 