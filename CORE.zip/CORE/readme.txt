Read me! - Important:

Set right to file: 
config.php 444
Robots.txt set rights to: 444.  - for security! 
and nobody can write to your files!

htaccess you find at protect wordpress in my portfolio:)


Works with wordpress: 6.1.1
Tested with: 6.2 - works!

Other things:
ini_set('memory_limit','512M');
define('WP_MEMORY_LIMIT','512M');


show no errros:

ini_set('display_errors','Off');
ini_set('error_reporting E_ALL);

define('WP_DEBUG',false);      *//After:
define('WP_DEBUG_DISPLAY',false);

Maybe:
define('WP_DISABLE_FATAL_ERROR_HANDLER',true);