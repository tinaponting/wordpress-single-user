Read me! - Important:

Set right to file: 
config.php 444
Robots.txt set rights to: 444.  - for security! 
and nobody can write to your files!

htaccess you find at protect wordpress in my portfolio:)

Tested with: 6.2 - works!

Other things:
ini_set('memory_limit','512M');
define('WP_MEMORY_LIMIT','512M');


show no errros:

define('WP_DEBUG',false);    -  *//After:
define('WP_DEBUG_DISPLAY',false);

Maybe:
define('WP_DISABLE_FATAL_ERROR_HANDLER',true);

If you want control of updating:
define('AUTOMATIC_UPDATER_DISABLED',true);