Read me! - Important:

Set right to file: 
config.php 444
Robots.txt set rights to: 444.  - for security! 
and nobody can write to your files!

htaccess you find at protect wordpress in my portfolio:)