<?php
define('WP_CACHE',true); // Boost Cache Plugin
define('DB_NAME','teskedsgumman_se_db_bloggligan');
define('DB_USER','teskedsgumman_se');
define('DB_PASSWORD','Xum4TwUEGN8acLAwnP39SgF68yLGE12');
define('DB_HOST','mysql9.unoeuro.com');
define('DB_CHARSET','UTF8');
define('DB_COLLATE','');
/**#@+
/**
* Authentication unique keys and salts.
*/
define('AUTH_KEY','Nv5Ir$B~H*)r%yF_Y*;e w 1zCX9~v(1C2qCzGE:3l:Yb`&Flj.iOp/Xx@.)QWZC');
define('SECURE_AUTH_KEY','~iA@=AO@R;I)Zh1hha9Iu<lNm0EM(sZh`dtrRh$<dS%=<$@RAqtIG~lj$&XYHe.F');
define('LOGGED_IN_KEY','-~ xKuLI]i@FOC$M*KNu=V~AIotVfc>V>28Xuu]mQF>4M}<o;8)[8c!TIl)gu?/B');
define('NONCE_KEY','{,n@H&5p8gkFJ=VN@AXNKAV?zvAqUcW{2J1d9jZTEI{`uNVQWxqv}hKEQejCd48H');
define('AUTH_SALT','UF([]c+,s/}UkiGZTrG9aGK.yorRdHRUCy(=Al@M6]Ackzy.o^(:(=>u{3mS?A|G');
define('SECURE_AUTH_SALT','?2!kTZVf~7jZq7em~Ie]w^;b@[-2elW5GbgD.iHEcaD)J>-vXBN=o|+x!sZeSY3M');
define('LOGGED_IN_SALT','l4&]ac+Z,ZzC?5PgqOjB=L/[+rHNlY,uRErR2?`s/,(boW>`ezzvM?])!,<(ehQr');
define('NONCE_SALT','`3liAw!oVTl^KFq/f4|Ph+21,U80,+19}/9je$4]0%B_V<0 !`?;5HV*snyM`~bj');
/**#@-*/
/**
* WordPress database table prefix.
*/
$table_prefix = 'wp_';
/**
* For developers: WordPress debugging mode.
*/
define('WP_DEBUG',false);
if(!defined('ABSPATH')){define('ABSPATH',__DIR__ .'/');
}
/** Sets up WordPress vars and included files. */
require_once ABSPATH.'wp-settings.php';
define('DISALLOW_FILE_EDIT',true); 
define('DISALLOW_FILE_MODS',true);
define('DISABLE_WP_CRON',true);
ob_start();?>