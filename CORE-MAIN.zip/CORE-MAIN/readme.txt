Read me! - Important:

Set right to file: 
config.php 444
Robots.txt set rights to: 444.  - for security! 
and nobody can write to your files!
All google verificatiton and so on. 444
htaccess you find at protect wordpress in my portfolio:)

Tested with: 6.5 - works!

Other things:
define('WP_MEMORY_LIMIT','512M');


show no errros:

define('WP_DEBUG',false);    -  *//After:
define('WP_DEBUG_DISPLAY',false);

Maybe:
define('WP_DISABLE_FATAL_ERROR_HANDLER',true);

If you want control of updating:
define('AUTOMATIC_UPDATER_DISABLED',true);