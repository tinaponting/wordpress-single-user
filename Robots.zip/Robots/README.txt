READ ME:

#### If wanted/Can be  aggresive:

China crawlers:
###Baidu:

User-agent: Baiduspider 
Allow: /
User-agent: Baiduspider-video 
Allow: /
User-agent: Baiduspider-image 
Allow: /
User-agent: BaiduSpider-Ads 
Allow: /
User-agent: BaiduSpider-Mobile 
Allow: /
User-agent: Baiduspider-News 
Allow: /

### HaoSou

User-agent: HaoSouSpider
Allow: / 
User-agent: Haosou 360 spider
Allow: /
User-agent: 360Spider
Allow: /
User-agent: 360Spider-Image
Allow: /
User-agent: 360Spider-Video
Allow: /

## Sogu
User-agent: Sosospider
Allow: / 
User-agent: Sosospider/2.0 
Allow: /
User-agent: Sosoimagespider 
Allow: /
User-agent: Sogou Spider 
Allow: /
User-agent: Sogou blog 
Allow: /
User-agent: Sogou head spider 
Allow: /
User-agent: Sogou inst spider 
Allow: /
User-agent: Sogou News Spider
Allow: / 
User-agent: Sogou Orion spider 
Allow: /
User-agent: Sogou spider2
Allow: / 
User-agent: Sogou web spider
Allow: / 
User-agent: Sogou-Test-Spider
Allow: / 

## soso

User-agent: Sosospider
Allow: / 
User-agent: Sosospider/2.0 
Allow: /
User-agent: Sosoimagespider 
Allow: /
User-agent: Sogou Spider 
Allow: /
User-agent: Sogou-Test-Spider
Allow: / 


User-agent: YioopBot
Allow: / 
User-agent: YisouSpider 
Allow: /
