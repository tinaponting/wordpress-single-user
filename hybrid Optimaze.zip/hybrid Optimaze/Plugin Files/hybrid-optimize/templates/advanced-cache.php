<?php

// Hybrid Optimize

if (!headers_sent()) {
    header('x-hybrid-optimize-cache: MISS');
    header('x-hybrid-optimize-source: PHP');
}

if (!isset($_SERVER['REQUEST_METHOD']) || !in_array($_SERVER['REQUEST_METHOD'], ['HEAD', 'GET'])) {
    return false;
}

if (!empty($_COOKIE)) {
    $cookies_regex =
        '/(wordpress_[a-f0-9]+|comment_author|wp-postpass|wordpress_no_cache|wordpress_logged_in|woocommerce_cart_hash|woocommerce_items_in_cart|woocommerce_recently_viewed|edd_items_in_cart)/';
    $cookies = implode('', array_keys($_COOKIE));
    if (preg_match($cookies_regex, $cookies)) {
        return false;
    }
}

if (!empty($_GET)) {
    $query_strings_regex = 'QUERY_STRING_REGEX_TO_REPLACE';
    if (sizeof(preg_grep($query_strings_regex, array_keys($_GET), PREG_GREP_INVERT)) > 0) {
        return false;
    }
}

$host = $_SERVER['HTTP_HOST'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$cache_file_path = WP_CONTENT_DIR . "/uploads/hybrid-optimize/$host$path" . 'index.html';

if (!is_readable($cache_file_path)) {
    return false;
}

header('x-hybrid-optimize-cache: HIT');

$cache_last_modified = filemtime($cache_file_path);
header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $cache_last_modified) . ' GMT');

$http_modified_since = isset($_SERVER['HTTP_IF_MODIFIED_SINCE'])
    ? $_SERVER['HTTP_IF_MODIFIED_SINCE']
    : '';

if ($http_modified_since && strtotime($http_modified_since) >= $cache_last_modified) {
    header($_SERVER['SERVER_PROTOCOL'] . ' 304 Not Modified', true, 304);
    exit();
}

readfile($cache_file_path);
exit();
