<?php

namespace Hybrid_Optimize\Loader;

use Hybrid_Optimize\I18n\I18n;
use Hybrid_Optimize\Cache\Purge;
use Hybrid_Optimize\Helper\Helper;
use Hybrid_Optimize\Parser\Parser;
use Hybrid_Optimize\Server\Server;
use Hybrid_Optimize\Admin\Admin_Bar;
use Hybrid_Optimize\Preload\Preload;
use Hybrid_Optimize\Options\Options;
use Hybrid_Optimize\Admin\Action_Links;
use Hybrid_Optimize\Lazy_Load\Lazy_Load;
use Hybrid_Optimize\Optimization\Optimization;
use Hybrid_Optimize\Lazy_Load\Lazy_Load_Images;
use Hybrid_Optimize\Lazy_Load\Lazy_Load_Videos;
use Hybrid_Optimize\Lazy_Load\Lazy_Load_Iframes;
use Hybrid_Optimize\Compatibility\Compatibility;
use Hybrid_Optimize\Emojis_Removal\Emojis_Removal;


class Loader
{
    public function __construct()
    {
        $this->add_compatibility_hooks();
        $this->add_locale_hooks();
        $this->add_admin_hooks();
        $this->add_options_hooks();
        $this->add_lazyload_hooks();
        $this->add_purge_hooks();
        $this->add_frontend_hooks();
        $this->add_emojis_removal_hooks();
        $this->add_preload_hooks();
        $this->add_server_hooks();
        $this->add_parser_hooks();
    }
    public function add_locale_hooks()
    {
        add_action('plugins_loaded', array(new I18n(), 'textdomain'));
    }

    public function add_admin_hooks()
    {
        add_filter('plugin_action_links', [new Action_Links(), 'add_action_links'], 10, 5);
        add_action('admin_bar_menu', [new Admin_Bar(), 'add_admin_bar_links'], 999);
        add_action('wp_ajax_admin_bar_purge_cache', array(new Admin_Bar(), 'purge_cache'));
    }

    public function add_compatibility_hooks()
    {
        add_action('admin_init', [new Compatibility(), 'update_non_compatible_plugins']);
        add_action('admin_notices', [new Compatibility(), 'add_notice']);
    }

    public function add_options_hooks()
    {
        add_action('admin_menu', [new Options(), 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [new Options(), 'enqueue_resources']);
        add_action('rest_api_init', [new Options(), 'api_init']);
    }

    public function add_purge_hooks()
    {
        if (Helper::get_option('auto_purge', false)) {
            add_action('save_post', [new Purge(), 'auto_purge_on_save_post']);
            add_action('wp_update_comment_count', [new Purge(), 'auto_purge_on_comment']);
            add_action('woocommerce_product_set_stock', [new Purge(), 'auto_purge_on_stock']);
            add_action('woocommerce_variation_set_stock', [new Purge(), 'auto_purge_on_stock']);
        }
    }

    public function add_preload_hooks()
    {
        add_action('wp_enqueue_scripts', [new Preload(), 'load_scripts']);
    }

    public function add_frontend_hooks()
    {
        if (
            is_admin() ||
            Helper::check_for_builders()
        ) {
            return;
        }

        if (Helper::get_option('remove_query_strings', false)) {
            add_filter('style_loader_src', array(new Optimization(), 'remove_query_strings'));
            add_filter('script_loader_src', array(new Optimization(), 'remove_query_strings'));
        }

        if (Helper::get_option('defer_js', false)) {
            add_action('wp_print_scripts', array(new Optimization(), 'prepare_scripts_for_async_load'), PHP_INT_MAX);
            add_filter('script_loader_tag', array(new Optimization(), 'add_async_attribute'), 10, 3);
        }
    }

    public function add_emojis_removal_hooks()
    {
        if (Helper::get_option('disable_emojis', false)) {
            remove_action('wp_head', 'print_emoji_detection_script', 7);
            remove_action('admin_print_scripts', 'print_emoji_detection_script');
            remove_action('wp_print_styles', 'print_emoji_styles');
            remove_action('admin_print_styles', 'print_emoji_styles');
            remove_filter('the_content_feed', 'wp_staticize_emoji');
            remove_filter('comment_text_rss', 'wp_staticize_emoji');
            remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
            add_filter('tiny_mce_plugins', array(new Emojis_Removal(), 'disable_emojis_tinymce'));
            add_filter('wp_resource_hints', array(new Emojis_Removal(), 'disable_emojis_remove_dns_prefetch'), 10, 2);
        }
    }

    public function add_lazyload_hooks()
    {
        if (
            Helper::is_mobile()
        ) {
            return;
        }

        if (Helper::get_option('lazyload_iframes', false)) {
            add_filter('the_content', [new Lazy_Load_Iframes(), 'iframes'], 10, 2);
            add_filter('the_content', [new Lazy_Load_Videos(), 'videos'], 10, 2);
        }
        if (Helper::get_option('lazyload_images', false)) {
            add_filter('the_content', [new Lazy_Load_Images(), 'images'], 10, 2);
            add_filter('widget_text', [new Lazy_Load_Images(), 'images'], 10, 3);
            add_filter('get_avatar', [new Lazy_Load_Images(), 'images'], 10, 6);
            add_filter('post_thumbnail_html', [new Lazy_Load_Images(), 'images'], 10, 5);

            if (class_exists('woocommerce')) {
                add_filter('woocommerce_product_get_image', [new Lazy_Load_Images(), 'images'], 10, 5);
                add_filter('woocommerce_single_product_image_thumbnail_html', [new Lazy_Load_Images(), 'images'], 10, 2);
            }
        }

        add_filter('wp_lazy_loading_enabled', '__return_false');
        add_action('wp_enqueue_scripts', [new Lazy_Load(), 'load_scripts']);
        add_action('wp_footer', [new Lazy_Load(), 'lazy_config'], 9999);
    }

    public function add_parser_hooks()
    {
        add_action('init', [new Parser(), 'start_bufffer']);
        add_action('shutdown', [new Parser(), 'end_buffer']);
    }

    public function add_server_hooks()
    {
        new Server();
    }
}
