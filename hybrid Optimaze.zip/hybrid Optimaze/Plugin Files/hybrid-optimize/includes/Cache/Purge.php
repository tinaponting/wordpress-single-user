<?php

namespace Hybrid_Optimize\Cache;

use Hybrid_Optimize\Helper\Helper;
use Hybrid_Optimize\Preload\Preload;

class Purge
{
    private static $instance;

    public static function get_instance()
    {
        if (null == self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function auto_purge_on_save_post($post_id)
    {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
            return;
        }

        if (get_post_status($post_id) !== 'publish') {
            return;
        }

        Purge::purge_cached_pages();
        Preload::get_instance()->preload_cache();

        $urls = [];
        $pages = get_pages();
        $urls = array_map(function ($page) {
            get_permalink($page->ID);
        }, $pages);

        array_push($urls, home_url());

        $page_for_post = get_option('page_for_posts');
        if ($page_for_post) {
            array_push($urls, get_permalink($page_for_post));
        }

        array_push($urls, get_permalink($post_id));

        array_push($urls, get_author_posts_url($post_id));

        $categories = get_the_category($post_id);
        foreach ($categories as $category) {
            array_push($urls, get_category_link($category->term_id));
        }

        if (class_exists('woocommerce') && get_post_type($post_id) === 'product') {

            $shop_page_url = get_permalink(wc_get_page_id('shop'));
            array_push($urls, $shop_page_url);

            $product_categories = get_the_terms($product_id, 'product_cat');
            if ($product_categories) {
                foreach ($product_categories as $product_category) {
                    array_push($urls, get_category_link($product_category->term_id));
                }
            }
        }

        $urls = array_unique($urls);
        Purge::purge_by_urls($urls);
        Preload::get_instance()->preload_urls($urls);
    }

    public function auto_purge_on_comment($post_id)
    {
        $url = get_permalink($post_id);
        Purge::purge_by_urls([$url]);
        Preload::get_instance()->preload_urls([$url]);
    }

    public function auto_purge_on_stock($product)
    {
        $url = get_permalink($product->get_id());
        Purge::purge_by_urls([$url]);
        Preload::get_instance()->preload_urls([$url]);
    }

    public function purge_by_urls($urls)
    {
        foreach ($urls as $url) {
            Purge::delete_page_from_url($url);
        }
    }
    public function purge_cached_pages()
    {
        $files = Helper::rglob(HYBRID_OPTIMIZE_CACHE_DIR . '*.html', GLOB_BRACE);
        foreach ($files as $file) {
            @unlink($file);
        }
    }

    public function purge_entire_cache()
    {
        self::delete_folder(HYBRID_OPTIMIZE_CACHE_DIR);
    }

    private function delete_page_from_url($url)
    {
        $path = parse_url($url, PHP_URL_PATH);
        $cache_file_path = HYBRID_OPTIMIZE_CACHE_DIR . $path . 'index.html';
        @unlink($cache_file_path);
    }

    private function delete_folder($path)
    {
        return is_file($path)
            ? @unlink($path)
            : array_map(__METHOD__, glob($path . '/*')) == @rmdir($path);
    }

    public function cache_flush()
    {

        $this->delete_folder(WP_CONTENT_DIR . '/uploads/hybrid-optimize/');

        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
    }
}
