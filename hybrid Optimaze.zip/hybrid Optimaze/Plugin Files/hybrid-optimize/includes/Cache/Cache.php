<?php

namespace Hybrid_Optimize\Cache;

use Hybrid_Optimize\Helper\Helper;

class Cache
{
    private static $default_exclude_keywords = [
        '/login',
        '/cart',
        '/checkout',
        '/account',
        '/my-account',
        '/wp-admin',
        '/feed',
        '.xml',
        '.txt',
        '.php',
    ];

    private static $default_ignore_queries = [
        'age-verified',
        'ao_noptimize',
        'usqp',
        'cn-reloaded',
        'sscid',
        'ef_id',
        's_kwcid',
        '_bta_tid',
        '_bta_c',
        'dm_i',
        'fb_action_ids',
        'fb_action_types',
        'fb_source',
        'fbclid',
        'utm_id',
        'utm_source',
        'utm_campaign',
        'utm_medium',
        'utm_expid',
        'utm_term',
        'utm_content',
        '_ga',
        'gclid',
        'campaignid',
        'adgroupid',
        'adid',
        '_gl',
        'gclsrc',
        'gdfms',
        'gdftrk',
        'gdffi',
        '_ke',
        'trk_contact',
        'trk_msg',
        'trk_module',
        'trk_sid',
        'mc_cid',
        'mc_eid',
        'mkwid',
        'pcrid',
        'mtm_source',
        'mtm_medium',
        'mtm_campaign',
        'mtm_keyword',
        'mtm_cid',
        'mtm_content',
        'msclkid',
        'epik',
        'pp',
        'pk_source',
        'pk_medium',
        'pk_campaign',
        'pk_keyword',
        'pk_cid',
        'pk_content',
        'redirect_log_mongo_id',
        'redirect_mongo_id',
        'sb_referer_host',
        'ref',
    ];

    private static $instance;

    public static function get_instance()
    {
        if (null == self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public static function is_page_excluded()
    {
        $current_url = home_url($_SERVER['REQUEST_URI']);
        $keywords = Helper::explode_lines(Helper::get_option('cache_exclude_urls'));
        $keywords = array_merge($keywords, self::$default_exclude_keywords);
        if (Helper::any_keywords_match_string($keywords, $current_url)) {
            return true;
        }
        return false;
    }

    public static function is_url_allowed($url)
    {
        $keywords = Helper::explode_lines(Helper::get_option('cache_exclude_urls'));
        $keywords = array_merge($keywords, self::$default_exclude_keywords);
        if (Helper::any_keywords_match_string($keywords, $url)) {
            return false;
        }
        return true;
    }

    public static function is_page_cacheable()
    {
        if (is_user_logged_in()) {
            return false;
        }

        if (is_404()) {
            return false;
        }

        if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] != 'GET') {
            return false;
        }

        if (!empty($_COOKIE)) {

            $cookies_regex =
                '/(wordpress_[a-f0-9]+|comment_author|wp-postpass|wordpress_no_cache|wordpress_logged_in|woocommerce_cart_hash|woocommerce_items_in_cart|woocommerce_recently_viewed|edd_items_in_cart)/';

            $cookies = implode('', array_keys($_COOKIE));

            if (preg_match($cookies_regex, $cookies)) {
                return false;
            }
        }

        if (!empty($_GET)) {

            $query_strings_regex = self::get_ignore_queries_regex();

            if (sizeof(preg_grep($query_strings_regex, array_keys($_GET), PREG_GREP_INVERT)) > 0) {
                return false;
            }
        }

        return true;
    }

    public static function cache_page($html)
    {
        $cache_file_path = HYBRID_OPTIMIZE_CACHE_DIR . parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        @mkdir($cache_file_path, 0755, true);
        file_put_contents($cache_file_path . 'index.html', "\xEF\xBB\xBF" . $html);
    }


    public static function get_ignore_queries_regex()
    {
        $get_queries = Helper::explode_lines(Helper::get_option('cache_query_strings'));

        $queries = array_merge($get_queries, self::$default_ignore_queries);
        $queries_regex = join('|', $queries);
        $queries_regex = "/^($queries_regex)$/";
        return $queries_regex;
    }

    public static function get_cached_pages_count()
    {
        $cache_pages = self::rglob(HYBRID_OPTIMIZE_CACHE_DIR . '*.html', GLOB_BRACE);
        return count($cache_pages);
    }

    public static function rglob($pattern, $flags = 0)
    {
        $files = glob($pattern, $flags);
        foreach (glob(dirname($pattern) . '/*', GLOB_ONLYDIR | GLOB_NOSORT) as $dir) {
            $files = array_merge($files, self::rglob($dir . '/' . basename($pattern), $flags));
        }
        return $files;
    }
}
