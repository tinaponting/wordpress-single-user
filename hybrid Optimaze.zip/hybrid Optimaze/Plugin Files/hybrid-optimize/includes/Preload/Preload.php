<?php

namespace Hybrid_Optimize\Preload;

use Hybrid_Optimize\Cache\Cache;
use Hybrid_Optimize\Cache\Purge;
use Hybrid_Optimize\Helper\Helper;
use Hybrid_Optimize\Sitemap\Sitemap;

class Preload
{
    private static $instance;

    public static function get_instance()
    {
        if (null == self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function preload_urls($urls)
    {
        $urls = array_filter($urls, [new Cache(), 'is_url_allowed']);
        file_put_contents(HYBRID_OPTIMIZE_CACHE_DIR . 'preload.json', json_encode(array_values($urls)));
        Preload::preload_url(Preload::get_next_url());
    }

    public function preload_cache()
    {
        Purge::get_instance()->purge_entire_cache();
        $urls = Sitemap::get_instance()->fetch_sitemap_urls();
        $urls = array_filter($urls, [new Cache(), 'is_url_allowed']);
        file_put_contents(HYBRID_OPTIMIZE_CACHE_DIR . 'preload.json', json_encode(array_values($urls)));
        Preload::preload_url(Preload::get_next_url());
    }

    public function remove_page_from_preload()
    {
        $url = home_url($_SERVER['REQUEST_URI']);
        $preload_file = HYBRID_OPTIMIZE_CACHE_DIR . 'preload.json';
        $urls = @json_decode(file_get_contents($preload_file)) ?? [];
        $urls = array_diff($urls, [$url]);
        file_put_contents(HYBRID_OPTIMIZE_CACHE_DIR . 'preload.json', json_encode(array_values($urls)));
    }

    public function get_next_url()
    {
        $preload_file = HYBRID_OPTIMIZE_CACHE_DIR . 'preload.json';
        $urls = @json_decode(file_get_contents($preload_file)) ?? [];
        $url_to_preload = array_shift($urls);
        file_put_contents($preload_file, json_encode(array_values($urls)));
        return $url_to_preload;
    }

    public function preload_url($url)
    {
        if (!isset($url)) {
            return;
        }

        wp_remote_get($url, [
            'timeout' => 0.01,
            'blocking' => false,
            'sslverify' => false,
            'headers' => ['x-hybrid-optimize-preload' => true],
            'user-agent' => 'Hybrid Optimize',
        ]);
    }

    public function load_scripts()
    {
        if (!Helper::get_option('preload_links')) {
            return;
        }

        if (current_user_can('manage_options')) {
            return;
        }

        if (function_exists('is_amp_endpoint') && is_amp_endpoint()) {
            return;
        }

        wp_enqueue_script(
            'hybrid-optimize-preload',
            HYBRID_OPTIMIZE_URL . 'assets/js/preload.min.js',
            array(),
            HYBRID_OPTIMIZE_VERSION,
            true
        );
    }
}
