<?php

namespace Hybrid_Optimize\Combinator;

use Hybrid_Optimize\Helper\Helper;
use Hybrid_Optimize\Optimization\Optimization;

class Css_Combinator extends Abstract_Combinator
{
    private $combined_styles_exclude_list = array(
        'amelia-elementor-widget-font',
        'amelia_booking_styles_vendor',
        'amelia_booking_styles',
        'uag-style',
        'buy_sell_ads_pro_template_stylesheet',
    );

    public $regex_parts = array(
        '~',
        '<link\s+([^>]+',
        '[\s\'"])?',
        'href\s*=\s*[\'"]\s*?',
        '(',
        '[^\'"]+\.css',
        '(?:\?[^\'"]*)?',
        ')\s*?',
        '[\'"]',
        '([^>]+)?',
        '\/?>',
        '~',
    );

    private static $instance;

    public $excluded_urls = array();

    public function __construct()
    {
        parent::__construct();
        self::$instance = $this;
    }

    public static function get_instance()
    {
        if (null == self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function run($html)
    {

        $this->prepare_excluded_styles();

        $html_without_comments = $this->hide_comments($html);

        $styles = $this->get_items($html_without_comments);

        if (empty($styles)) {
            return $html;
        }

        $data = $this->parse($styles);

        if (empty($data)) {
            return $html;
        }

        return $this->get_new_html($html, $data);
    }

    public function parse($styles)
    {

        $data = array();

        foreach ($styles as $style) {

            if ($this->is_excluded($style)) {
                continue;
            }

            $data[$style[2]] = $style[0];
        }

        return $data;
    }

    public function prepare_excluded_styles()
    {
        global $wp_styles;

        $excluded_handles = array_merge($this->combined_styles_exclude_list, Helper::explode_lines(Helper::get_option('combine_css_exclude')));

        if (empty($wp_styles->registered)) {
            return;
        }

        $registered = array_keys($wp_styles->registered);
        $excluded   = array();

        foreach ($excluded_handles as $handle) {

            if (!in_array($handle, $registered)) {
                continue;
            }

            $excluded[] = trim(str_replace(Helper::get_site_url(), '', strtok($wp_styles->registered[$handle]->src, '?')), '/\\');
        }

        $this->excluded_urls = $excluded;
    }

    public function is_excluded($style)
    {
        if (false !== @strpos($style[0], 'media=') && !preg_match('/media=["\'](?:\s*|[^"\']*?\b(all|screen)\b[^"\']*?)["\']/i', $style[0])) {
            return true;
        }

        if (false !== @strpos($style[0], 'only screen and')) {
            return true;
        }

        $host = parse_url($style[2], PHP_URL_HOST);

        if (
            @strpos(Helper::get_home_url(), $host) === false &&
            !@strpos($style[2], 'wp-includes')
        ) {
            return true;
        }

        $src  = Optimization::remove_query_strings($style[2]);

        if (in_array(str_replace(trailingslashit(Helper::get_site_url()), '', $src), $this->excluded_urls)) {
            return true;
        }

        return false;
    }

    public function get_new_html($html, $styles_data)
    {
        foreach ($styles_data as $url => $tag) {
            $html = str_replace($tag, '', $html);
            $new_content[$url] = $this->get_content($url);
        }

        $tag_data = $this->create_temp_file_and_get_url($new_content, 'combined-css', 'css');

        $replace = '</title><link rel="stylesheet" id="' . $tag_data['handle'] . '" href="' . $tag_data['url'] . '" media="all" />';

        if (Helper::get_option('preload_combined_css', false)) {
            $replace .= ' <link rel="preload" href="' . $tag_data['url'] . '" as="style">';
        }

        return preg_replace('~<\/title>~', $replace, $html, 1);
    }

    public function get_content_with_replacements($contents)
    {
        $new_content = array();

        foreach ($contents as $url => $content) {
            $dir = trailingslashit(dirname($url));

            $content = $this->check_for_imports($content, $url);

            $content = $this->swap_font_display($content);

            $content = preg_replace(
                '~^(\/\/|\/\*)(#|@)\s(sourceURL|sourceMappingURL)=(.*)(\*\/)?$~m',
                '',
                $content
            );

            $regex = '/url\s*\(\s*(?!["\']?data:)(?![\'|\"]?[\#|\%|])([^)]+)\s*\)([^;},\s]*)/i';

            $replacements = array();

            preg_match_all($regex, $content, $matches);

            if (!empty($matches)) {
                foreach ($matches[1] as $index => $match) {
                    $match = trim($match, " \t\n\r\0\x0B\"'");

                    if (false == preg_match('~(http(?:s)?:)?\/\/(?:[\w-]+\.)*([\w-]{1,63})(?:\.(?:\w{2,}))(?:$|\/)~', $match)) {
                        $replacement = str_replace($match, $dir . $match, $matches[0][$index]);

                        $replacements[$matches[0][$index]] = $replacement;
                    }
                }
            }

            $keys = array_map('strlen', array_keys($replacements));
            array_multisort($keys, SORT_DESC, $replacements);

            $new_content[] = str_replace(array_keys($replacements), array_values($replacements), $content);
        }

        return implode("\n", $new_content);
    }

    private function check_for_imports($content, $url)
    {

        $dir = trailingslashit(dirname($url));

        preg_match_all('/@import\s+["\'](.+?)["\'];?/i', $content, $matches);

        if (empty($matches)) {
            return $content;
        }

        foreach ($matches[1] as $match) {
            $import_content = $this->get_content_with_replacements(
                array(
                    $url => $this->get_content($dir . $match),
                )
            );

            $content = str_replace($matches[0], $import_content, $content);
        }

        return $content;
    }

    public function swap_font_display($content)
    {

        if (!Helper::get_option('optimize_web_fonts', false)) {
            return $content;
        }

        preg_match_all('/@font-face\s*{([\s\S]*?)}/i', $content, $matches);

        if (empty($matches)) {
            return $content;
        }

        foreach ($matches[1] as $match) {

            preg_match_all('/font-display:.([a-zA-Z]+)/i', $match, $result);

            $new = empty($result[0]) ? $match . ";font-display: swap;\n" : str_replace($result[0], 'font-display: swap', $match);

            $content = str_replace($match, $new, $content);
        }

        return $content;
    }
}
