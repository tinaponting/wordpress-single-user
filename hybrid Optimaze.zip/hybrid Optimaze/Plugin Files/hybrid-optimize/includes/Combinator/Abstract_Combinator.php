<?php

namespace Hybrid_Optimize\Combinator;

use Hybrid_Optimize\Helper\Helper;
use Hybrid_Optimize\Optimization\Optimization;

abstract class Abstract_Combinator
{
    private $wp_filesystem = null;

    public function __construct()
    {

        if (null === $this->wp_filesystem) {
            $this->wp_filesystem = Helper::setup_wp_filesystem();
        }

        $this->assets_dir = Optimization::get_instance()->assets_dir;
    }

    public function get_content($url)
    {

        $url = Optimization::remove_query_strings($url);

        $filepath = Optimization::get_original_filepath($url);

        return $this->wp_filesystem->get_contents(preg_replace('~#038;(.*)~', '', $filepath));
    }

    public function create_temp_file_and_get_url($content, $handle, $type = 'css')
    {
        $style_hash = md5(implode('', $content));
        $new_file   = $this->assets_dir . 'hybrid-optimize-combined-' . $type . '-' . $style_hash . '.' . $type;
        $url        = str_replace(ABSPATH, Helper::get_site_url(), $new_file);

        $data = array(
            'handle' => 'hybrid-optimize-combined-' . $type . '-' . $style_hash,
            'url'    => $url,
        );

        if (is_file($new_file)) {
            return $data;
        }

        $this->wp_filesystem->touch($new_file);

        $this->wp_filesystem->put_contents(
            $new_file,
            $this->get_content_with_replacements($content)
        );

        return $data;
    }

    public function hide_comments($html)
    {
        return preg_replace('/<!--(.*)-->/Uis', '', $html);
    }

    public function get_items($html)
    {
        $regex = implode('', $this->regex_parts);

        preg_match_all($regex, $html, $matches, PREG_SET_ORDER);

        return $matches;
    }

    public function get_external_file_content($url, $type, $add_dir = '')
    {

        $hash     = md5($url);

        $dir      = Optimization::get_instance()->assets_dir . $add_dir;

        $file_path = $dir . '/' . $hash . '.' . $type;

        $wp_filesystem = Helper::setup_wp_filesystem();

        if ($wp_filesystem->exists($file_path)) {

            $content = $wp_filesystem->get_contents($file_path);

            if (!empty($content)) {
                return $content;
            }
        }

        if (!$wp_filesystem->exists($dir)) {
            $is_dir_created = $wp_filesystem->mkdir($dir);
        }

        $request = wp_remote_get($url);

        if (is_wp_error($request)) {
            return false;
        }

        if (200 !== wp_remote_retrieve_response_code($request)) {
            return false;
        }

        if (false === $wp_filesystem->touch($file_path)) {
            return false;
        }

        $file_content = wp_remote_retrieve_body($request);

        $wp_filesystem->put_contents(
            $file_path,
            $file_content
        );

        return $file_content;
    }
}
