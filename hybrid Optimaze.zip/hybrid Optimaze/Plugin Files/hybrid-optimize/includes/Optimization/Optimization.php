<?php

namespace Hybrid_Optimize\Optimization;

use Hybrid_Optimize\Helper\Helper;

class Optimization
{
    public $assets_dir = null;

    const LIMIT = 1000000000;

    private $blacklisted_async_scripts = array(
        'moxiejs',
        'wc-square',
        'wc-braintree',
        'wc-authorize-net-cim',
        'sv-wc-payment-gateway-payment-form',
        'paypal-checkout-sdk',
        'uncode-app',
        'uncode-plugins',
        'uncode-init',
        'lodash',
        'wp-api-fetch',
        'wp-i18n',
        'wp-polyfill',
        'wp-url',
        'wp-hooks',
        'houzez-google-map-api',
        'wpascript',
    );

    private $blacklisted_async_regex = array(
        'sv-wc-payment-gateway-payment-form-v',
    );

    private static $instance;

    public function __construct()
    {
        $this->set_assets_directory_path();

        self::$instance = $this;
        $this->blacklisted_async_scripts = array_merge(
            $this->blacklisted_async_scripts,
            Helper::explode_lines(Helper::get_option('defer_js_exclude'))
        );
    }

    public static function get_instance()
    {
        if (null == self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function set_assets_directory_path()
    {
        if (null !== $this->assets_dir) {
            return;
        }

        $uploads_dir = Helper::get_uploads_dir();

        $directory = $uploads_dir . '/hybrid-optimize';

        $is_directory_created = !is_dir($directory) ? $this->create_directory($directory) : true;

        if ($is_directory_created) {
            $this->assets_dir = trailingslashit($directory);
        }
    }

    public function create_directory($directory)
    {
        $is_directory_created = wp_mkdir_p($directory);

        if (false === $is_directory_created) {
            error_log(sprintf('Cannot create directory: %s.', $directory));
        }

        return $is_directory_created;
    }

    public static function get_original_filepath($original)
    {
        $home_url = Helper::get_site_url();

        $result = parse_url($home_url);

        $replace = $result['scheme'] . '://';

        $new = preg_replace('~^https?:\/\/|^\/\/~', $replace, $original);

        if (@strpos($new, $home_url) !== false) {
            $original_filepath = str_replace($home_url, ABSPATH, $new);
        } else {
            $original_filepath = untrailingslashit(ABSPATH) . $new;
        }

        return $original_filepath;
    }

    public function get_assets_dir()
    {
        return $this->assets_dir;
    }

    public function prepare_scripts_for_async_load()
    {
        global $wp_scripts;

        if (!is_object($wp_scripts) || is_user_logged_in()) {
            return;
        }

        $scripts = wp_clone($wp_scripts);
        $scripts->all_deps($scripts->queue);

        $excluded_scripts = $this->blacklisted_async_scripts;

        foreach ($this->blacklisted_async_regex as $regex) {
            $excluded_scripts = array_merge($excluded_scripts, Helper::get_script_handle_regex($regex, $scripts->to_do));
        }

        foreach ($scripts->to_do as $handle) {
            if (
                in_array($handle, $excluded_scripts) ||
                empty($wp_scripts->registered[$handle]->src)
            ) {
                continue;
            }

            $wp_scripts->registered[$handle]->src = add_query_arg('hybrid-optimize-async', 1, $wp_scripts->registered[$handle]->src);
        }
    }

    public function add_async_attribute($tag, $handle, $src)
    {
        if (@strpos($src, 'hybrid-optimize-async=1') !== false) {
            $new_src = remove_query_arg('hybrid-optimize-async', $src);
            return str_replace(
                array(
                    '<script ',
                    '-hybrid-optimize-async',
                    $src,
                    '?#038;',
                ),
                array(
                    '<script defer ',
                    '',
                    $new_src,
                    '?',
                ),
                $tag
            );
        }

        return $tag;
    }

    public static function remove_query_strings($src)
    {
        $host = parse_url($src, PHP_URL_HOST);

        if (empty($host)) {
            return $src;
        }

        if (@strpos(Helper::get_home_url(), $host) === false) {
            return $src;
        }

        $exclude_list = array();

        if (
            !empty($exclude_list) &&
            preg_match('~' . implode('|', $exclude_list) . '~', $src)
        ) {
            return $src;
        }

        return remove_query_arg(
            array(
                'ver',
                'version',
                'v',
                'mts',
                'nomtcache',
                'generated',
                'timestamp',
                'cache',
            ),
            html_entity_decode($src)
        );
    }

    public function get_assets()
    {

        global $wp;
        global $wp_styles;
        global $wp_scripts;
        remove_all_actions('elementor/editor/after_enqueue_styles', 10);

        $wp_scripts->queue[] = 'wc-jilt';

        ob_start();
        do_action('wp', $wp);
        do_action('wp_enqueue_scripts');
        do_action('elementor/editor/after_enqueue_styles');
        ob_get_clean();

        unset($wp_scripts->queue['wc-jilt']);

        return array(
            'scripts' => $this->get_assets_data($wp_scripts),
            'styles'  => $this->get_assets_data($wp_styles),
        );
    }

    private function get_assets_data($assets)
    {
        $excludes = array(
            'moxiejs',
            'elementor-frontend',
        );

        $data = array(
            'header'       => array(),
            'default'      => array(),
            'non_minified' => array(),
        );

        $items = wp_clone($assets);
        $items->all_deps($items->queue);

        foreach ($items->to_do as $index => $handle) {
            if (
                in_array($handle, $excludes) ||
                !is_bool(@strpos($handle, 'hybrid-optimize')) ||
                !is_string($items->registered[$handle]->src)
            ) {
                continue;
            }

            if (1 !== $items->groups[$handle]) {
                $data['header'][] = $this->get_asset_data($items->registered[$handle]);
            }

            if (@strpos($items->registered[$handle]->src, '.min.') === false) {
                $data['non_minified'][] = $this->get_asset_data($items->registered[$handle]);
            }

            $data['default'][] = $this->get_asset_data($items->registered[$handle]);
        }

        return $data;
    }

    public function get_asset_data($item)
    {
        $src = preg_replace('~https?://~', '', Optimization::remove_query_strings($item->src));

        preg_match('~wp-content(/(.*?)/(.*?)/.*)~', $src, $matches);

        $data = array(
            'value'       => $item->handle,
            'title'       => !empty($matches[1]) ? $matches[1] : $item->src,
            'group'       => !empty($matches[2]) ? substr($matches[2], 0, -1) : __('others', 'hybrid-optimize'),
            'name'        => !empty($matches[3]) ? $this->get_plugin_info($matches[3]) : false,
        );

        $data['group_title'] = empty($data['name']) ? $data['group'] : $data['group'] . ': ' . $data['name'];

        return $data;
    }

    private function get_plugin_info($path, $field = 'name')
    {
        $active_plugins = get_option('active_plugins');
        foreach ($active_plugins as $plugin_file) {
            if (false === @strpos($plugin_file, $path)) {
                continue;
            }

            $plugin = get_file_data(WP_PLUGIN_DIR . '/' . $plugin_file, array($field => 'Plugin Name'));
        }

        if (!empty($plugin[$field])) {
            return $plugin[$field];
        }
        return $path;
    }
}
