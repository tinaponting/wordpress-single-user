<?php

namespace Hybrid_Optimize\CDN;

use Hybrid_Optimize\Helper\Helper;

class CDN
{
    private static $instance;

    public static function get_instance()
    {
        if (null == self::$instance) {
            static::$instance = new self();
        }

        return self::$instance;
    }

    public function run($html)
    {
        $site_url        = quotemeta(get_option('home'));
        $url_regex       = '(https?:|)' . substr($site_url, strpos($site_url, '//'));
        $cdn_included     = 'wp\-content|wp\-includes';
        $cdn_content_include = Helper::get_option('cdn_content_include');
        if (!empty($cdn_content_include)) {
            $included_list = array_map('trim', explode(',', $cdn_content_include));
            if (count($included_list) > 0) {
                $cdn_included = implode('|', array_map('quotemeta', array_filter($included_list)));
            }
        }
        $regex         = '#(?<=[(\"\'])(?:' . $url_regex . ')?/(?:((?:' . $cdn_included . ')[^\"\')]+)|([^/\"\']+\.[^/\"\')]+))(?=[\"\')])#';
        $html_with_cdn = preg_replace_callback($regex, [$this, 'rewrited_cdn_url'], $html);

        return $html_with_cdn;
    }

    public function rewrited_cdn_url($cname)
    {
        $cdn_url = Helper::get_option('cdn_url');

        if (!empty($cdn_url)) {
            $cdn_content_exclude = Helper::get_option('cdn_content_exclude');
            if (!empty($cdn_content_exclude)) {
                $cdn_excluded = array_map('trim', explode(',', $cdn_content_exclude));

                foreach ($cdn_excluded as $excluded) {
                    if (
                        !empty($excluded) &&
                        false !== stristr($cname[0], $excluded)
                    ) {
                        return $cname[0];
                    }
                }
            }
            if (
                is_admin_bar_showing() &&
                isset($_GET['preview']) &&
                'true' === $_GET['preview']
            ) {
                return $cname[0];
            }
            $site_url = get_option('home');
            $site_url = substr($site_url, strpos($site_url, '//'));
            if (strpos($cname[0], '//') === 0) {
                return str_replace($site_url, $cdn_url, $cname[0]);
            }
            if (strstr($cname[0], $site_url)) {
                return str_replace(['http:' . $site_url, 'https:' . $site_url], $cdn_url, $cname[0]);
            }
            return $cdn_url . $cname[0];
        }

        return $cname[0];
    }
}
