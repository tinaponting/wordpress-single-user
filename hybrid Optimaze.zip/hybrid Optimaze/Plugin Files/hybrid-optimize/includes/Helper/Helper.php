<?php

namespace Hybrid_Optimize\Helper;

class Helper
{
    public static function get_option($option = '', $default = null)
    {
        $options = get_option('hybrid_optimize_options');
        return (isset($options[$option])) ? $options[$option] : $default;
    }

    public static function explode_lines($text, $unique = true)
    {
        if (!$text) {
            return [];
        }

        if (true === $unique) {
            return array_filter(array_unique(array_map('trim', preg_split('/\r\n|\r|\n/', $text))));
        } else {
            return array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $text)));
        }
    }

    public static function is_mobile()
    {
        if (function_exists('wp_is_mobile')) {
            return wp_is_mobile();
        }

        if (empty($_SERVER['HTTP_USER_AGENT'])) {
            $is_mobile = false;
        } elseif (
            @strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile') !== false
            || @strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false
            || @strpos($_SERVER['HTTP_USER_AGENT'], 'Silk/') !== false
            || @strpos($_SERVER['HTTP_USER_AGENT'], 'Kindle') !== false
            || @strpos($_SERVER['HTTP_USER_AGENT'], 'BlackBerry') !== false
            || @strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== false
            || @strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mobi') !== false
        ) {
            $is_mobile = true;
        } else {
            $is_mobile = false;
        }

        return $is_mobile;
    }

    public static function check_for_builders()
    {

        $builder_paramas =  array(
            'fl_builder',
            'vcv-action',
            'et_fb',
            'ct_builder',
            'tve',
            'preview',
            'elementor-preview',
            'uxb_iframe',
            'trp-edit-translation',
        );

        foreach ($builder_paramas as $param) {
            if (isset($_GET[$param])) {
                return true;
            }
        }

        return false;
    }

    public static function check_upload_dir_permissions()
    {
        if (!function_exists('fileperms')) {
            return true;
        }

        if (700 <= intval(substr(sprintf('%o', fileperms(self::get_uploads_dir())), -3))) {
            return true;
        }

        return false;
    }

    public function sitehealth_remove_https_status($tests)
    {
        unset($tests['async']['https_status']);
        return $tests;
    }

    public static function get_current_url()
    {

        if (!isset($_SERVER['HTTP_HOST'])) {
            return '';
        }

        $protocol = isset($_SERVER['HTTPS']) ? 'https' : 'http';

        return $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    }

    public static function setup_wp_filesystem()
    {
        global $wp_filesystem;
        if (empty($wp_filesystem)) {
            require_once ABSPATH . '/wp-admin/includes/file.php';
            WP_Filesystem();
        }

        return $wp_filesystem;
    }

    public static function is_cron_disabled()
    {
        if (defined('DISABLE_WP_CRON') && true == DISABLE_WP_CRON) {
            return 1;
        }

        return 0;
    }

    public function hide_warnings_in_rest_api()
    {
        if (self::is_rest()) {
            error_reporting(E_ERROR | E_PARSE);
        }
    }

    public static function is_rest()
    {
        $prefix = rest_get_url_prefix();

        if (
            defined('REST_REQUEST') && REST_REQUEST ||
            (isset($_GET['rest_route']) &&
                0 === @strpos(trim($_GET['rest_route'], '\\/'), $prefix, 0)
            )
        ) {
            return true;
        }

        $rest_url    = wp_parse_url(site_url($prefix));
        $current_url = wp_parse_url(add_query_arg(array()));

        return 0 === @strpos($current_url['path'], $rest_url['path'], 0);
    }

    public static function get_home_url()
    {
        $url = get_option('home');

        $scheme = is_ssl() ? 'https' : parse_url($url, PHP_URL_SCHEME);

        $url = set_url_scheme($url, $scheme);

        return trailingslashit($url);
    }

    public static function get_site_url()
    {
        $url = get_option('siteurl');

        $scheme = is_ssl() ? 'https' : parse_url($url, PHP_URL_SCHEME);

        $url = set_url_scheme($url, $scheme);

        return trailingslashit($url);
    }

    public static function get_uploads_dir()
    {
        $upload_dir = wp_upload_dir();

        $base_dir = $upload_dir['basedir'];

        if (defined('UPLOADS')) {
            $base_dir = ABSPATH . UPLOADS;
        }

        return $base_dir;
    }

    public static function get_script_handle_regex($regex, $scripts)
    {
        if (empty($regex) || empty($scripts)) {
            return array();
        }

        $matched_handles = array();

        foreach ($scripts as $handle) {
            if (false !== strpos($handle, $regex)) {
                $matched_handles[] = $handle;
            }
        }

        return $matched_handles;
    }

    public static function any_keywords_match_string($keywords, $string)
    {
        $keywords = array_filter($keywords);

        foreach ($keywords as $keyword) {
            if (stripos($string, $keyword) !== false) {
                return true;
            }
        }

        return false;
    }
    public static function rglob($pattern, $flags = 0)
    {
        $files = glob($pattern, $flags);
        foreach (glob(dirname($pattern) . '/*', GLOB_ONLYDIR | GLOB_NOSORT) as $dir) {
            $files = array_merge($files, self::rglob($dir . '/' . basename($pattern), $flags));
        }
        return $files;
    }
}
