<?php

namespace Hybrid_Optimize\Parser;

use Hybrid_Optimize\CDN\CDN;
use Hybrid_Optimize\Cache\Cache;
use Hybrid_Optimize\Helper\Helper;
use Hybrid_Optimize\Preload\Preload;
use Hybrid_Optimize\Minifier\Minifier;
use Hybrid_Optimize\Prefetch\Prefetch;
use Hybrid_Optimize\Combinator\Js_Combinator;
use Hybrid_Optimize\Combinator\Css_Combinator;
use Hybrid_Optimize\Combinator\Font_Combinator;
use Hybrid_Optimize\Lazy_Load\Lazy_Load_Images;

class Parser
{
    public function run($html)
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            return $html;
        }

        if (!preg_match('/<\/html>/i', $html)) {
            return $html;
        }

        if (
            $this->is_amp_enabled($html) ||
            $this->is_xml($html) ||
            is_feed() ||
            is_admin()
        ) {
            return $html;
        }

        if ($this->is_invalid_page()) {
            return $html;
        }

        if (is_user_logged_in() && !Helper::get_option('logged_in_cache')) {
            return $html;
        }

        if (Cache::is_page_excluded()) {
            return $html;
        }

        $optimized_html = $this->optimize_for_visitors($html);

        Preload::get_instance()->remove_page_from_preload();

        if (isset($_SERVER['HTTP_X_HYBRID_OPTIMIZE_PRELOAD'])) {
            Preload::get_instance()->preload_url(Preload::get_instance()->get_next_url());
        }

        if (Helper::get_option('cache', false)) {
            if (Cache::is_page_cacheable()) {
                header('X-Cacheable: yes', true);
                Cache::cache_page($optimized_html);
            }
        }
        return $optimized_html;
    }

    public function optimize_for_visitors($html)
    {
        if (Helper::get_option('combine_css', false)) {
            $html = Css_Combinator::get_instance()->run($html);
        }

        if (
            Helper::get_option('combine_js') &&
            !$this->is_post_request()
        ) {
            $html = Js_Combinator::get_instance()->run($html);
        }

        if (Helper::get_option('optimize_web_fonts', false)) {
            $html = Font_Combinator::get_instance()->run($html);
        }

        $html = Prefetch::get_instance()->run($html);

        if (Helper::get_option('image_dimensions', false)) {
            $html = Lazy_Load_Images::image_dimensions($html);
        }

        if (Helper::get_option('minify_html', false)) {
            $html = Minifier::get_instance()->run($html);
        }

        if (Helper::get_option('enable_cdn', false)) {
            $html = CDN::get_instance()->run($html);
        }
        return $html;
    }

    public function is_amp_enabled($html)
    {
        $is_amp = substr($html, 0, 200);
        return preg_match('/<html[^>]+(amp|⚡)[^>]*>/', $is_amp);
    }

    public function is_xml($content)
    {
        $xml_part = substr($content, 0, 20);

        return preg_match('/<\?xml version="/', $xml_part);
    }

    private function is_invalid_page()
    {
        $current_url = home_url($_SERVER['REQUEST_URI']);
        $keywords = ['/wp-admin', '/feed', '.xml', '.txt', '.php'];
        array_push($keywords, wp_login_url());

        if (Helper::any_keywords_match_string($keywords, $current_url)) {
            return true;
        }
        return false;
    }

    public function is_post_request()
    {
        if ('POST' === $_SERVER['REQUEST_METHOD']) {
            return true;
        }
        return false;
    }

    public function start_bufffer()
    {
        ob_start(array($this, 'run'));
    }

    public function end_buffer()
    {
        if (ob_get_length()) {
            ob_end_flush();
        }
    }
}
