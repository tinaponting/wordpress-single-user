<?php

namespace Hybrid_Optimize\Emojis_Removal;

class Emojis_Removal
{
    public function disable_emojis_tinymce($plugins)
    {
        if (!is_array($plugins)) {
            return array();
        }

        return array_diff($plugins, array('wpemoji'));
    }

    public function disable_emojis_remove_dns_prefetch($urls, $relation_type)
    {

        if ('dns-prefetch' == $relation_type) {

            foreach ($urls as $key => $url) {

                if (@strpos($url, 'https://s.w.org/images/core/emoji/') === false) {
                    continue;
                }

                unset($urls[$key]);
            }
        }

        return $urls;
    }
}
