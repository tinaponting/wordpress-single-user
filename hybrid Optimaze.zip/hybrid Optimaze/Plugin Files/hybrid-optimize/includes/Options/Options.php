<?php

namespace Hybrid_Optimize\Options;

use Hybrid_Optimize\Cache\Cache;
use Hybrid_Optimize\Helper\Helper;

class Options
{
    private $plugin_name = HYBRID_OPTIMIZE_SLUG;

    private $version = HYBRID_OPTIMIZE_VERSION;

    private $namespace = 'hybrid-optimize-setting-api/';

    private $rest_version = 'v1';

    public function add_admin_menu()
    {

        add_menu_page(
            esc_html__('Hybrid Optimize', HYBRID_OPTIMIZE_SLUG),
            esc_html__('Hybrid Optimize', HYBRID_OPTIMIZE_SLUG),
            'manage_options',
            $this->plugin_name,
            array($this, 'add_setting_root_div')
        );
    }

    public function add_setting_root_div()
    {

        echo '<div id="' . $this->plugin_name . '"></div>';
?>
        <script>
            jQuery(function($) {
                $('<div class="logo"><img src="<?php echo esc_url(HYBRID_OPTIMIZE_URL); ?>assets/img/logo.png"></div>').insertBefore("#tab-panel-0-dashboard");
            });
        </script>
<?php
    }

    public function check_key($code)
    {

        $personalToken = "2j7ajCrzVZoEOJm9gFwwfnZvO2TmV6sF";
        $userAgent = "Purchase code verification";

        if (!preg_match("/^([a-f0-9]{8})-(([a-f0-9]{4})-){3}([a-f0-9]{12})$/i", $code)) {
            return "Invalid code";
        }

        $code = trim($code);
        $url = 'https://api.envato.com/v3/market/author/sale?code=' . urlencode(trim($code)) . '';

        $response = wp_remote_get(
            $url,
            array(
                'headers' => array(
                    'Authorization' => "Bearer " . $personalToken,
                    'User-Agent' => $userAgent
                )
            )
        );

        $body = json_decode($response['body']);

        return $body;
    }

    public function enqueue_resources()
    {

        $screen              = get_current_screen();
        $admin_scripts_bases = array('toplevel_page_' . $this->plugin_name);
        if (!(isset($screen->base) && in_array($screen->base, $admin_scripts_bases))) {
            return;
        }
        $dependency = array('lodash', 'wp-api-fetch', 'wp-i18n', 'wp-components', 'wp-element');

        wp_enqueue_script($this->plugin_name, HYBRID_OPTIMIZE_URL . 'assets/js/admin.js', $dependency, $this->version, true);

        wp_enqueue_style($this->plugin_name, HYBRID_OPTIMIZE_URL . 'assets/css/admin.css', array('wp-components'), $this->version);

        wp_set_script_translations($this->plugin_name, $this->plugin_name);



        $sale = $this->check_key(Helper::get_option('account_key'));
        if (!empty($sale)) {
            if (!empty($sale->license)) {

                $buyer = $sale->buyer;

                $supportDate = strtotime($sale->supported_until);
                $supported = $supportDate > time() ? "Yes" : "Expired";

                wp_localize_script(
                    $this->plugin_name,
                    'hybridOptimizeBuild',
                    array(
                        'version' => $this->version,
                        'cached_count' => Cache::get_cached_pages_count(),
                        'root_id' => $this->plugin_name,
                        'rest'    => array(
                            'namespace' => $this->namespace,
                            'version'   => $this->rest_version,
                        ),
                        'buyer_name' => $buyer,
                        'supported' => $supported,
                        'is_active' => esc_html__('Active', HYBRID_OPTIMIZE_SLUG),
                        'purge_cache' => wp_nonce_url(admin_url('admin-ajax.php?action=admin_bar_purge_cache'), 'ho-purge-cache'),
                    )
                );
            } else {
                $text = esc_html__('Unavailable', HYBRID_OPTIMIZE_SLUG);
                wp_localize_script(
                    $this->plugin_name,
                    'hybridOptimizeBuild',
                    array(
                        'version' => $this->version,
                        'cached_count' => Cache::get_cached_pages_count(),
                        'root_id' => $this->plugin_name,
                        'rest'    => array(
                            'namespace' => $this->namespace,
                            'version'   => $this->rest_version,
                        ),
                        'buyer_name' => $text,
                        'supported' => $text,
                        'is_active' => $text,
                        'purge_cache' => wp_nonce_url(admin_url('admin-ajax.php?action=admin_bar_purge_cache'), 'ho-purge-cache'),
                    )
                );
            }
        }
    }

    public function api_init()
    {
        $namespace = $this->namespace . $this->rest_version;

        register_rest_route(
            $namespace,
            '/set_settings',
            array(
                array(
                    'methods'             => \WP_REST_Server::EDITABLE,
                    'callback'            => array($this, 'set_settings'),
                    'permission_callback' => function () {
                        return current_user_can('manage_options');
                    },
                ),
            )
        );
        register_rest_route(
            $namespace,
            '/get_settings',
            array(
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array($this, 'get_settings'),
                    'permission_callback' => function () {
                        return current_user_can('manage_options');
                    },
                ),
            )
        );
    }

    public function set_settings(\WP_REST_Request $request)
    {
        $params = $request->get_params();
        if (isset($params['settings'])) {
            $this->delete_options();
            $this->set_options($params['settings']);
        }
        return rest_ensure_response($this->get_options());
    }

    public function get_settings(\WP_REST_Request $request)
    {
        return rest_ensure_response($this->get_options());
    }

    public function hybrid_optimize_default_options()
    {
        $default_options = array(
            'cache'  => false,
            'auto_purge'  => false,
            'cache_exclude_urls' => array(),
            'cache_query_strings' => array(),
            'logged_in_cache'  => false,
            'minify_html'  => false,
            'minify_html_exclude' => array(),
            'optimize_web_fonts'  => false,
            'remove_query_strings'  => false,
            'disable_emojis'  => false,
            'minify_css'  => false,
            'minify_css_exclude' => array(),
            'combine_css'  => false,
            'combine_css_exclude' => array(),
            'preload_combined_css'  => false,
            'minify_js'  => false,
            'minify_js_exclude' => array(),
            'combine_js'  => false,
            'combine_js_exclude' => array(),
            'defer_js'  => false,
            'defer_js_exclude' => array(),
            'lazyload_images'  => false,
            'lazyload_exclude' => array(),
            'image_dimensions'  => false,
            'lazyload_iframes'  => false,
            'preload_links'  => false,
            'dns_prefetch' => array(),
            'preload_fonts' => array(),
            'enable_cdn'  => false,
            'cdn_url' => array(),
            'cdn_content_include' => array(),
            'cdn_content_exclude' => array(),
            'account_email' => array(),
            'account_key' => array(),
        );
        return apply_filters('hybrid_optimize_default_options', $default_options);
    }

    public function get_options($key = '')
    {
        $options         = get_option('hybrid_optimize_options');
        $default_options = $this->hybrid_optimize_default_options();

        if (!empty($key)) {
            if (isset($options[$key])) {
                return $options[$key];
            }
            return isset($default_options[$key]) ? $default_options[$key] : false;
        } else {
            if (!is_array($options)) {
                $options = array();
            }
            return array_merge($default_options, $options);
        }
    }

    public function delete_options($key = '')
    {
        if (!empty($key)) {
            $options = $this->get_options();
            if (isset($options[$key])) {
                unset($options[$key]);
                return update_option('hybrid_optimize_options', $options);
            }
        } else {
            return delete_option('hybrid_optimize_options');
        }
    }

    public function set_options($settings)
    {
        $setting_keys = array_keys($this->hybrid_optimize_default_options());
        $options      = array();
        foreach ($settings as $key => $value) {
            if (in_array($key, $setting_keys)) {

                if (
                    'cache' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'auto_purge' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'cache_exclude_urls' == $key
                ) {
                    $value = sanitize_textarea_field($value);
                } elseif (
                    'cache_query_strings' == $key
                ) {
                    $value = sanitize_textarea_field($value);
                } elseif (
                    'logged_in_cache' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'minify_html' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'minify_html_exclude' == $key
                ) {
                    $value = sanitize_textarea_field($value);
                } elseif (
                    'optimize_web_fonts' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'remove_query_strings' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'disable_emojis' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'minify_css' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'minify_css_exclude' == $key
                ) {
                    $value = sanitize_textarea_field($value);
                } elseif (
                    'combine_css' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'combine_css_exclude' == $key
                ) {
                    $value = sanitize_textarea_field($value);
                } elseif (
                    'preload_combined_css' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'minify_js' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'minify_js_exclude' == $key
                ) {
                    $value = sanitize_textarea_field($value);
                } elseif (
                    'combine_js' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'combine_js_exclude' == $key
                ) {
                    $value = sanitize_textarea_field($value);
                } elseif (
                    'defer_js' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'defer_js_exclude' == $key
                ) {
                    $value = sanitize_textarea_field($value);
                } elseif (
                    'lazyload_images' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'lazyload_exclude' == $key
                ) {
                    $value = sanitize_textarea_field($value);
                } elseif (
                    'image_dimensions' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'lazyload_iframes' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'preload_links' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'dns_prefetch' == $key
                ) {
                    $value = sanitize_textarea_field($value);
                } elseif (
                    'preload_fonts' == $key
                ) {
                    $value = sanitize_textarea_field($value);
                } elseif (
                    'enable_cdn' == $key
                ) {
                    $value =  (bool) $value;
                } elseif (
                    'cdn_url' == $key
                ) {
                    $value = sanitize_text_field($value);
                } elseif (
                    'cdn_content_include' == $key
                ) {
                    $value = sanitize_text_field($value);
                } elseif (
                    'cdn_content_exclude' == $key
                ) {
                    $value = sanitize_textarea_field($value);
                } elseif (
                    'account_email' == $key
                ) {
                    $value = sanitize_text_field($value);
                } elseif (
                    'account_key' == $key
                ) {
                    $value = sanitize_text_field($value);
                } else {
                    $value = sanitize_key($value);
                }
                $options[$key] = $value;
            }
        }
        update_option('hybrid_optimize_options', $options);
    }
}
