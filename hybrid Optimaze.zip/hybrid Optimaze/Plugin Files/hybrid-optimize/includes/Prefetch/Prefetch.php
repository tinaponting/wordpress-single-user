<?php

namespace Hybrid_Optimize\Prefetch;

use Hybrid_Optimize\Helper\Helper;

class Prefetch
{
    private static $instance;

    public function __construct()
    {
        self::$instance = $this;
    }

    public static function get_instance()
    {
        if (null == self::$instance) {
            static::$instance = new self();
        }

        return self::$instance;
    }

    public function run($html)
    {
        $urls = Helper::explode_lines(Helper::get_option('dns_prefetch'));

        if (empty($urls)) {
            return $html;
        }

        $new_html = '';

        foreach ($urls as $url) {

            $url_without_protocol = preg_replace('~(?:(?:https?:)?(?:\/\/)(?:www\.|(?!www)))?((?:.*?)\.(?:.*))~', '//$1', $url);

            $new_html .= '<link rel="dns-prefetch" href="' . $url_without_protocol . '"/>';
        }

        return str_replace('</head>', $new_html . '</head>', $html);
    }
}
