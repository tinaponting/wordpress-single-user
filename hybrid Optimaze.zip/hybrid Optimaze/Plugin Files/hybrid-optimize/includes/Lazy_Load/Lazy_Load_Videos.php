<?php

namespace Hybrid_Optimize\Lazy_Load;

use Hybrid_Optimize\Helper\Helper;

class Lazy_Load_Videos
{

    public function videos($content)
    {
        if (empty($content)) {
            return $content;
        }
        $matches = array();
        preg_match_all('/<video[\s\r\n]+(.*?)>/is', $content, $matches);

        $search = array();
        $replace = array();
        foreach ($matches[0] as $video_html) {
            $flag = false;
            $lazyload_exclusions = Helper::explode_lines(Helper::get_option('lazyload_exclude'));

            $default_lazyload_exclusions = [
                'data-no-lazy',
                'skip-lazy',
            ];

            $lazyload_exclusions = array_merge($lazyload_exclusions, $default_lazyload_exclusions);

            if ($lazyload_exclusions) {
                foreach ($lazyload_exclusions as $class) {
                    if (!empty($class)) {
                        if (strpos($video_html, $class) !== false) {
                            $flag = true;
                            break;
                        }
                    }
                }
                if ($flag) {
                    continue;
                }
            }
            $output = '';
            $output = preg_replace('/<video(.*?)src=/is', '<video $1data-src=', $video_html);
            if (preg_match('/class=["\']/i', $output)) {
                $output = preg_replace('/class=(["\'])(.*?)["\']/is', 'class=$1$2 lazyload$1', $output);
            } else {
                $output = preg_replace('/<video/is', '<video class="lazyload"', $output);
            }
            array_push($search, $video_html);
            array_push($replace, $output);
        }
        $search = array_unique($search);
        $replace = array_unique($replace);
        $content = str_replace($search, $replace, $content);

        return $content;
    }
}
