<?php

namespace Hybrid_Optimize\Lazy_Load;

use Hybrid_Optimize\Helper\Helper;

class Lazy_Load_Images
{
    public function images($content)
    {
        $matches = array();
        preg_match_all('/<img[\s\r\n]+(.*?)>/is', $content, $matches);

        $search = array();
        $replace = array();
        foreach ($matches[0] as $img_html) {
            $flag = false;
            if (strpos($img_html, 'data-src') !== false || strpos($img_html, 'data-srcset') !== false) {
                continue;
            }
            $lazyload_exclusions = Helper::explode_lines(Helper::get_option('lazyload_exclude'));
            $default_lazyload_exclusions = [
                'data-no-lazy',
                'skip-lazy',
            ];
            $lazyload_exclusions =  array_merge($lazyload_exclusions, $default_lazyload_exclusions);

            if ($lazyload_exclusions) {
                foreach ($lazyload_exclusions as $class) {
                    if (!empty($class)) {
                        if (strpos($img_html, $class) !== false) {
                            $flag = true;
                            break;
                        }
                    }
                }
                if ($flag) {
                    continue;
                }
            }
            $bg = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
            $class = 'lazyload';
            $output = '';
            $output = preg_replace('/<img(.*?)src=/is', '<img $1 src="' . $bg . '" data-src=', $img_html);
            $output = preg_replace('/<img(.*?)srcset=/is', '<img$1data-srcset=', $output);

            if (preg_match('/class=["\']/i', $output)) {
                $output = preg_replace('/class=(["\'])(.*?)["\']/is', 'class=$1$2 ' . $class . '$1', $output);
            } else {
                $output = preg_replace('/<img/is', '<img class="' . $class . '"', $output);
            }
            array_push($search, $img_html);
            array_push($replace, $output);
        }

        $search = array_unique($search);
        $replace = array_unique($replace);
        $content = str_replace($search, $replace, $content);

        return $content;
    }

    public static function image_dimensions($content)
    {
        preg_match_all('/<img[^>]+>/i', $content, $images);

        if (count($images) < 1) {
            return $content;
        }

        foreach ($images[0] as $image) {
            $attributes = 'src|srcset|longdesc|alt|class|id|usemap|align|border|hspace|vspace|crossorigin|ismap|sizes|width|height|style';
            preg_match_all('/(' . $attributes . ')=("[^"]*")/i', $image, $img);

            if (!in_array('src', $img[1])) {
                continue;
            }

            $widthIdx = array_search('width', $img[1]);
            $heightIdx = array_search('height', $img[1]);

            if ($widthIdx === false || $heightIdx === false || ($widthIdx !== false && $img[2][$widthIdx] == '""') || ($heightIdx !== false && $img[2][$heightIdx] == '""')) {
                $attributes = explode('|', $attributes);
                foreach ($attributes as $variable) {
                    ${$variable} = in_array($variable, $img[1]) ? ' ' . $variable . '=' . $img[2][array_search($variable, $img[1])] : '';
                }
                $src = $img[2][array_search('src', $img[1])];
                if (preg_match('/(.*).svg|.webp/i', $src)) {
                    if (!in_array('width', $img[1]) || !in_array('height', $img[1]) || (in_array('width', $img[1]) && in_array('""', $img[2])) || (in_array('height', $img[1]) && in_array('""', $img[2]))) {
                        $width = '100%';
                        $height = 'auto';
                    }
                } else {
                    if (preg_match('/^"(\.\.|\.|\/)\//', $src)) {
                        $absSrc = preg_replace('/^"(\.\.|\.|\/)\//', '', $src);
                        $absSrc = trailingslashit($_SERVER['DOCUMENT_ROOT']) . $absSrc;
                        list($width, $height) = getimagesize(str_replace("\"", "", $absSrc));
                    } else {
                        list($width, $height) = getimagesize(str_replace("\"", "", $src));
                    }
                    if (empty($width) && empty($height)) continue;
                }
                if (stripos($image, 'data-wpopti-lazyimg-src') !== false) {
                    $srcLabel = 'data-wpopti-lazyimg-src';
                } else {
                    $srcLabel = 'src';
                }
                $tag = sprintf('<img %s=%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s width="%s" height="%s">',  $srcLabel, $src, $style, $srcset, $longdesc, $alt, $class, $id, $usemap, $align, $border, $hspace, $vspace, $crossorigin, $ismap, $sizes, $width, $height);
                $content = str_replace($image, $tag, $content);
            }
        }
        return $content;
    }
}
