<?php

namespace Hybrid_Optimize\Lazy_Load;

class Lazy_Load
{
    public function load_scripts()
    {
        wp_enqueue_script(
            'hybrid-optimize-lazysizes',
            HYBRID_OPTIMIZE_URL . 'assets/js/lazysizes.min.js',
            array(),
            HYBRID_OPTIMIZE_VERSION,
            true
        );
    }

    public function lazy_config()
    {
        echo '<script>lazySizes.init();</script>';
    }
}
