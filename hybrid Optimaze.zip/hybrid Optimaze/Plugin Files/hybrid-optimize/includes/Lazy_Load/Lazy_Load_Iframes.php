<?php

namespace Hybrid_Optimize\Lazy_Load;

use Hybrid_Optimize\Helper\Helper;

class Lazy_Load_Iframes
{
    public function iframes($content)
    {
        if (empty($content)) {
            return $content;
        }

        $matches = array();
        preg_match_all('/<iframe[\s\r\n]+(.*?)>/is', $content, $matches);

        $search = array();
        $replace = array();

        foreach ($matches[0] as $iframe_html) {
            $flag = false;

            $lazyload_exclusions = Helper::explode_lines(Helper::get_option('lazyload_exclude'));

            $default_lazyload_exclusions = [
                'data-no-lazy',
                'skip-lazy',
            ];

            $lazyload_exclusions = array_merge($lazyload_exclusions, $default_lazyload_exclusions);

            if ($lazyload_exclusions) {
                foreach ($lazyload_exclusions as $class) {
                    if (!empty($class)) {
                        if (strpos($iframe_html, $class) !== false) {
                            $flag = true;
                            break;
                        }
                    }
                }
                if ($flag) {
                    continue;
                }
            }
            $output = '';
            $output = preg_replace('/<iframe(.*?)src=/is', '<iframe $1data-src=', $iframe_html);

            if (preg_match('/class=["\']/i', $output)) {
                $output = preg_replace('/class=(["\'])(.*?)["\']/is', 'class=$1$2 lazyload$1', $output);
            } else {
                $output = preg_replace('/<iframe/is', '<iframe class="lazyload"', $output);
            }

            array_push($search, $iframe_html);
            array_push($replace, $output);
        }

        $search = array_unique($search);
        $replace = array_unique($replace);
        $content = str_replace($search, $replace, $content);

        return $content;
    }
}
