<?php

namespace Hybrid_Optimize\Minifier;

use Hybrid_Optimize\Helper\Helper;
use Hybrid_Optimize\Optimization\Optimization;
use Hybrid_Optimize_CSS;
use Hybrid_Optimize_JS;

class Minifier
{

    private $wp_filesystem = null;

    private $assets_dir = null;

    private $js_ignore_list = array(
        'jquery',
        'jquery-core',
        'ai1ec_requirejs',
    );

    private $css_ignore_list = array(
        'uag-style',
    );

    private static $instance;

    private $exclude_params = array(
        'pdf-catalog',
        'tve',
        'elementor-preview',
        'preview',
        'wc-api',
        'method',
    );

    public function __construct()
    {
        if (null === $this->wp_filesystem) {
            $this->wp_filesystem = Helper::setup_wp_filesystem();
        }

        $this->assets_dir = Optimization::get_instance()->assets_dir;

        self::$instance = $this;

        $this->js_ignore_list = array_merge(
            $this->js_ignore_list,
            Helper::explode_lines(Helper::get_option('minify_js_exclude'))
        );

        $this->css_ignore_list = array_merge(
            $this->css_ignore_list,
            Helper::explode_lines(Helper::get_option('minify_css_exclude'))
        );
    }

    public static function get_instance()
    {
        if (null == self::$instance) {
            static::$instance = new self();
        }
        return self::$instance;
    }

    public function minify_scripts()
    {
        global $wp_scripts;

        if (
            !is_object($wp_scripts) ||
            null === $this->assets_dir ||
            $this->has_exclude_param()
        ) {
            return;
        }

        $scripts = wp_clone($wp_scripts);
        $scripts->all_deps($scripts->queue);

        $excluded_scripts = $this->js_ignore_list;

        foreach ($scripts->to_do as $handle) {

            if (
                stripos($wp_scripts->registered[$handle]->src, '.min.js') !== false ||
                false === $wp_scripts->registered[$handle]->src ||
                in_array($handle, $excluded_scripts) ||
                @strpos(Helper::get_home_url(), parse_url($wp_scripts->registered[$handle]->src, PHP_URL_HOST)) === false
            ) {
                continue;
            }

            $original_filepath = Optimization::get_original_filepath($wp_scripts->registered[$handle]->src);

            $filename = $this->assets_dir . $wp_scripts->registered[$handle]->handle . '.min.js';

            if (false !== strpos($wp_scripts->registered[$handle]->handle, '/')) {
                $filename = dirname($original_filepath) . '/' . str_replace('/', '-', $wp_scripts->registered[$handle]->handle) . '.min.css';
            }

            $is_minified_file_ok = $this->check_and_create_file($filename, $original_filepath);

            if ($is_minified_file_ok) {
                $wp_scripts->registered[$handle]->src = str_replace(ABSPATH, Helper::get_site_url(), $filename);
            }
        }
    }

    public function minify_scripts_lib($minifier_type, $filename, $original_filepath)
    {

        switch ($minifier_type) {
            case 'JS':
                $minifier = new Hybrid_Optimize_JS($original_filepath);
                break;
            case 'CSS':
                $minifier = new Hybrid_Optimize_CSS($original_filepath);
                break;
        }

        if (empty($minifier->minify($filename))) {
            return false;
        }

        return true;
    }

    private function check_and_create_file($new_file_path, $original_filepath)
    {
        if (!is_file($original_filepath)) {
            return false;
        }

        $original_filepath = Optimization::remove_query_strings(preg_replace('/\?.*/', '', $original_filepath));
        $new_file_path     = Optimization::remove_query_strings(preg_replace('/\?.*/', '', $new_file_path));

        $original_file_timestamp = file_exists($original_filepath) ? filemtime($original_filepath) : true;
        $minified_file_timestamp = file_exists($new_file_path) ? filemtime($new_file_path) : false;

        if ($original_file_timestamp === $minified_file_timestamp) {
            return true;
        }

        if (Helper::get_option('minify_css', false) || Helper::get_option('minify_js', false)) {
            $minifier_type = strtoupper(pathinfo($original_filepath, PATHINFO_EXTENSION));

            if (empty($minifier_type)) {
                return false;
            }

            $status = !$this->minify_scripts_lib($minifier_type, $new_file_path, $original_filepath);
        } else {

            exec(
                sprintf(
                    'minify %s --output=%s',
                    $original_filepath,
                    $new_file_path
                ),
                $output,
                $status
            );
        }

        if (1 === intval($status) || !file_exists($new_file_path)) {
            return false;
        }

        $this->wp_filesystem->touch($new_file_path, $original_file_timestamp);

        return true;
    }

    public function minify_styles()
    {
        global $wp_styles;

        if (
            !is_object($wp_styles) ||
            null === $this->assets_dir ||
            $this->has_exclude_param()
        ) {
            return;
        }

        $styles = wp_clone($wp_styles);
        $styles->all_deps($styles->queue);

        $excluded_styles = $this->css_ignore_list;

        foreach ($styles->to_do as $handle) {

            if (
                stripos($wp_styles->registered[$handle]->src, '.min.css') !== false ||
                false === $wp_styles->registered[$handle]->src ||
                in_array($handle, $excluded_styles) ||
                @strpos(Helper::get_home_url(), parse_url($wp_styles->registered[$handle]->src, PHP_URL_HOST)) === false
            ) {
                continue;
            }

            $original_filepath = Optimization::get_original_filepath($wp_styles->registered[$handle]->src);

            $parsed_url = parse_url($wp_styles->registered[$handle]->src);

            $filename = dirname($original_filepath) . '/' . $wp_styles->registered[$handle]->handle . '.min.css';

            if (false !== strpos($wp_styles->registered[$handle]->handle, '/')) {
                $filename = dirname($original_filepath) . '/' . str_replace('/', '-', $wp_styles->registered[$handle]->handle) . '.min.css';
            }

            if (!empty($parsed_url['query'])) {
                $filename = $filename . '?' . $parsed_url['query'];
            }

            $is_minified_file_ok = $this->check_and_create_file($filename, $original_filepath);

            if ($is_minified_file_ok) {
                $wp_styles->registered[$handle]->src = str_replace(ABSPATH, Helper::get_site_url(), $filename);
            }
        }
    }

    public function run($html)
    {

        if ($this->is_url_excluded()) {
            return $html;
        }

        return self::minify_html($html);
    }

    public function minify_html($buffer)
    {
        $content = Minify_Html::minify($buffer);
        return $content;
    }

    public function is_url_excluded()
    {
        $url = Helper::get_current_url();

        $excluded_urls = Helper::explode_lines(Helper::get_option('minify_html_exclude'));

        $prepared_parts = array_map(
            function ($item) {
                return str_replace('\*', '.*', preg_quote(str_replace(home_url(), '', $item), '/'));
            },
            $excluded_urls
        );

        $regex = sprintf(
            '/%s(%s)$/i',
            preg_quote(home_url(), '/'),
            implode('|', $prepared_parts)
        );

        preg_match($regex, $url, $matches);

        if (!empty($matches)) {
            return true;
        }

        if (!isset($_REQUEST)) {
            return false;
        }

        $excluded_params = $this->exclude_params;

        return $this->has_exclude_param($excluded_params);
    }

    public function has_exclude_param($params = array())
    {

        if (!isset($_REQUEST)) {
            return false;
        }

        if (empty($params)) {
            $params = $this->exclude_params;
        }

        foreach ($params as $param) {
            if (array_key_exists($param, $_REQUEST)) {
                return true;
            }
        }

        return false;
    }
}
