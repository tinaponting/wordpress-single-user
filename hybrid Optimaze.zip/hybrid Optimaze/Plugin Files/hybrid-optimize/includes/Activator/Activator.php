<?php

namespace Hybrid_Optimize\Activator;

use Hybrid_Optimize\Cache\Cache;
use Hybrid_Optimize\Helper\Helper;

class Activator
{
    public function activate()
    {
        $this->add_wp_cache_constant();

        $this->add_advanced_cache();

        $this->add_htaccess_rules();
    }

    public function add_wp_cache_constant()
    {
        $wp_config_file = Helper::setup_wp_filesystem()->abspath() . 'wp-config.php';

        if (!is_file($wp_config_file)) {
            $wp_config_file = Helper::setup_wp_filesystem()->touch($wp_config_file);
        }

        if (!is_file($wp_config_file) || !is_writable($wp_config_file)) {
            return;
        }

        $content = "\ndefine('WP_CACHE', true); // Added by Hybrid Optimize";

        $wp_config = file_get_contents($wp_config_file);

        $regex_for_wp_cache = '/define\([\'\"]WP_CACHE[\'\"].*/';
        $wp_config = preg_replace($regex_for_wp_cache, '', $wp_config);

        $wp_config = str_replace('<?php', '<?php' . $content, $wp_config);

        file_put_contents($wp_config_file, $wp_config);
    }

    public function add_advanced_cache()
    {
        $advanced_cache_contents = file_get_contents(
            HYBRID_OPTIMIZE_DIR . 'templates/advanced-cache.php'
        );

        $advanced_cache_contents = str_replace(
            'QUERY_STRING_REGEX_TO_REPLACE',
            Cache::get_ignore_queries_regex(),
            $advanced_cache_contents
        );

        file_put_contents(WP_CONTENT_DIR . '/advanced-cache.php', $advanced_cache_contents);
    }

    public function add_htaccess_rules()
    {
        $htaccess_file = Helper::setup_wp_filesystem()->abspath() . '.htaccess';

        if (!is_readable($htaccess_file) || !is_writeable($htaccess_file)) {
            return;
        }

        $htaccess_contents = file_get_contents($htaccess_file);

        $htaccess_contents = ltrim(
            preg_replace(
                '/\s*# BEGIN Hybrid Optimize.*# END Hybrid Optimize\s*?/isU',
                PHP_EOL . PHP_EOL,
                $htaccess_contents
            )
        );

        $hybrid_optimize_htaccess = file_get_contents(HYBRID_OPTIMIZE_DIR . 'templates/htaccess.txt');

        $server_name = preg_match('/LiteSpeed/', $_SERVER['SERVER_SOFTWARE']) ? 'LiteSpeed' : 'Apache';
        $hybrid_optimize_htaccess = str_replace('[WEB_SERVER_NAME]', $server_name, $hybrid_optimize_htaccess);

        $htaccess_contents = str_replace(
            '# BEGIN WordPress',
            $hybrid_optimize_htaccess . "\n\n# BEGIN WordPress",
            $htaccess_contents
        );

        file_put_contents($htaccess_file, $htaccess_contents);
    }
}
