<?php

namespace Hybrid_Optimize\Server;

use Hybrid_Optimize\Helper\Helper;

class Server
{
    public $plugin_slug;
    public $version;
    public $cache_key;
    public $cache_allowed;

    public function __construct()
    {

        $this->plugin_slug = HYBRID_OPTIMIZE_SLUG;
        $this->version = HYBRID_OPTIMIZE_VERSION;
        $this->cache_key = 'hybrid_optimize_update';
        $this->cache_allowed = true;
        add_filter('plugins_api', array($this, 'info'), 20, 3);
        add_filter('site_transient_update_plugins', array($this, 'update'));
        add_action('upgrader_process_complete', array($this, 'purge'), 10, 2);
        add_action('in_plugin_update_message-hybrid-optimize/hybrid-optimize.php', array($this, 'update_message'), 10, 2);
    }

    public function request()
    {
        $current_user = wp_get_current_user();
        $remote = get_transient($this->cache_key);

        if (false === $remote || !$this->cache_allowed) {

            $remote = wp_remote_get(

                add_query_arg(
                    array(
                        'account_email' => urlencode(Helper::get_option('account_email')),
                        'account_key' => urlencode(Helper::get_option('account_key')),
                        'account_site' => urlencode(get_home_url()),
                        'account_firstname' => urlencode($current_user->user_firstname),
                        'account_lastname' => urlencode($current_user->user_lastname),
                    ),
                    'https://api.masudatheme.com/license/checker.php'
                ),
                array(
                    'timeout' => 10,
                    'headers' => array(
                        'Accept' => 'application/json'
                    )
                )
            );

            if (
                is_wp_error($remote)
                || 200 !== wp_remote_retrieve_response_code($remote)
                || empty(wp_remote_retrieve_body($remote))
            ) {
                return false;
            }

            set_transient($this->cache_key, $remote, HOUR_IN_SECONDS);
        }

        $remote = json_decode(wp_remote_retrieve_body($remote));

        return $remote;
    }


    function info($res, $action, $args)
    {


        if ('plugin_information' !== $action) {
            return $res;
        }

        if ($this->plugin_slug !== $args->slug) {
            return $res;
        }

        $remote = $this->request();

        if (!$remote) {
            return $res;
        }

        $res = new \stdClass();

        $res->name = $remote->name;
        $res->slug = $remote->slug;
        $res->version = $remote->version;
        $res->tested = $remote->tested;
        $res->requires = $remote->requires;
        $res->author = $remote->author;
        $res->author_profile = $remote->author_profile;
        $res->download_link = $remote->download_url;
        $res->trunk = $remote->download_url;
        $res->requires_php = $remote->requires_php;
        $res->last_updated = $remote->last_updated;
        $res->sections = array(
            'changelog' => $remote->sections->changelog
        );

        if (!empty($remote->banners)) {
            $res->banners = array(
                'low' => $remote->banners->low,
                'high' => $remote->banners->high
            );
        }

        return $res;
    }

    public function update($transient)
    {

        if (empty($transient->checked)) {
            return $transient;
        }

        $remote = $this->request();

        if (
            $remote
            && version_compare($this->version, $remote->version, '<')
            && version_compare($remote->requires, get_bloginfo('version'), '<=')
            && version_compare($remote->requires_php, PHP_VERSION, '<')
        ) {
            $res = new \stdClass();
            $res->slug = $this->plugin_slug;
            $res->plugin = 'hybrid-optimize/hybrid-optimize.php';
            $res->new_version = $remote->version;
            $res->tested = $remote->tested;
            $res->package = $remote->download_url;

            $transient->response[$res->plugin] = $res;
        }

        return $transient;
    }

    public function purge($upgrader, $options)
    {

        if (
            $this->cache_allowed
            && 'update' === $options['action']
            && 'plugin' === $options['type']
        ) {
            delete_transient($this->cache_key);
        }
    }

    public function update_message($plugin_info_array, $plugin_info_object)
    {
        if (empty($plugin_info_array['package'])) {
            echo esc_html__(' Require valid license to update. You can update your license key in Hybrid Optimize > License', HYBRID_OPTIMIZE_SLUG);
        }
    }
}
