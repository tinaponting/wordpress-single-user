<?php

namespace Hybrid_Optimize\Admin;

use Hybrid_Optimize\Cache\Purge;

class Admin_Bar
{
    private static $instance;

    public static function get_instance()
    {
        if (null == self::$instance) {
            static::$instance = new self();
        }
        return self::$instance;
    }

    public function add_admin_bar_links($admin_bar)
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $args = array(
            'id'    => HYBRID_OPTIMIZE_SLUG,
            'title' => esc_html__('Hybrid Optimize', 'hybrid-optimize'),
            'href'   => esc_url(admin_url('admin.php?page=hybrid-optimize'))
        );
        $admin_bar->add_node($args);

        $args = array(
            'parent' => HYBRID_OPTIMIZE_SLUG,
            'id'     => 'ho_purge_cache',
            'title'  => esc_html__('Purge Cache', 'hybrid-optimize'),
            'href'   => wp_nonce_url(admin_url('admin-ajax.php?action=admin_bar_purge_cache'), 'ho-purge-cache'),
            'meta'   => false
        );
        $admin_bar->add_node($args);

        $args = array(
            'parent' => HYBRID_OPTIMIZE_SLUG,
            'id'     => 'ho_setting',
            'title'  => esc_html__('Settings', 'hybrid-optimize'),
            'href'   => esc_url(admin_url('admin.php?page=hybrid-optimize')),
            'meta'   => false
        );
        $admin_bar->add_node($args);
        $args = array(
            'parent' => HYBRID_OPTIMIZE_SLUG,
            'id'     => 'ho_support',
            'title'  => esc_html__('Support', 'hybrid-optimize'),
            'href'   => 'https://support.masudatheme.com',
            'meta'   => array(
                'target' => '_blank'
            )
        );
        $admin_bar->add_node($args);
    }

    public function purge_cache()
    {
        if (empty($_GET['_wpnonce'])) {
            return;
        }
        if (!wp_verify_nonce($_GET['_wpnonce'], 'ho-purge-cache')) {
            return;
        }

        Purge::get_instance()->cache_flush();

        wp_safe_redirect($_SERVER['HTTP_REFERER']);
        exit;
    }
}
