<?php

namespace Hybrid_Optimize\Admin;

class Action_Links
{
    private static $plugin;

    public function add_action_links($actions, $plugin_file)
    {
        $is_plugin = self::$plugin;

        if (!isset($is_plugin))
            $is_plugin = 'hybrid-optimize/hybrid-optimize.php';
        if ($is_plugin == $plugin_file) {

            $settings = array('settings' => '<a href="' . esc_url(admin_url('admin.php?page=hybrid-optimize')) . '">' . esc_html__('Settings', 'hybrid-optimize') . '</a>');
            $site_link = array('support' => '<a href="https://support.masudatheme.com" target="_blank">' . esc_html__('Support', 'hybrid-optimize') . '</a>');

            $actions = array_merge($settings, $actions);
            $actions = array_merge($site_link, $actions);
        }

        return $actions;
    }
}
