<?php

namespace Hybrid_Optimize\Sitemap;

use Hybrid_Optimize\Helper\Helper;

class Sitemap
{
    private static $instance;

    public static function get_instance()
    {
        if (null == self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function get_sitemap_url()
    {
        if (defined('WPSEO_VERSION') && get_option('wpseo')['enable_xml_sitemap']) {
            return \WPSEO_Sitemaps_Router::get_base_url('sitemap_index.xml');
        } elseif (defined('RANK_MATH_VERSION') && \RankMath\Helper::is_module_active('sitemap')) {
            return \RankMath\Sitemap\Router::get_base_url('sitemap_index.xml');
        } elseif (
            defined('AIOSEOP_VERSION') &&
            isset(get_option('aioseop_options')['modules']) &&
            get_option('aioseop_options')['modules']['aiosp_feature_manager_options']['aiosp_feature_manager_enable_sitemap'] === 'on'
        ) {
            return trailingslashit(home_url()) .
                apply_filters('aiosp_sitemap_filename', 'sitemap') .
                '.xml';
        } elseif (defined('THE_SEO_FRAMEWORK_VERSION') && the_seo_framework()->can_run_sitemap()) {
            return \The_SEO_Framework\Bridges\Sitemap::get_instance()->get_expected_sitemap_endpoint_url();
        } elseif (defined('SEOPRESS_VERSION') && !!seopress_xml_sitemap_general_enable_option()) {
            return Helper::get_home_url() . 'sitemaps.xml';
        } elseif (defined('SM_SUPPORTFEED_URL')) {
            return Helper::get_home_url() . 'sitemap.xml';
        } elseif (defined('XMLSF_VERSION')) {
            return Helper::get_home_url() . 'sitemap.xml';
        } elseif (defined('SLIM_SEO_VER')) {
            return Helper::get_home_url() . 'sitemap.xml';
        } elseif (defined('SQ_VERSION')) {
            return Helper::get_home_url() . 'sitemap.xml';
        } elseif (function_exists('csg_dashboard')) {
            return Helper::get_home_url() . 'sitemap.xml';
        }

        return Helper::get_home_url() . 'sitemap.xml';
    }

    public function fetch_sitemap_urls()
    {
        $sitemap_url = $this->get_sitemap_url();
        return $this->crawl_sitemap_recursive($sitemap_url);
    }

    public function crawl_sitemap_recursive($sitemap_url)
    {
        $xml = file_get_contents($sitemap_url);
        $xml = simplexml_load_string($xml);

        if (!$xml) {
            return [];
        }

        $urls = [];

        foreach ($xml->url as $value) {
            array_push($urls, (string) $value->loc);
        }

        if (count($urls)) {
            return $urls;
        }

        foreach ($xml->sitemap as $value) {
            $urls = array_merge($urls, $this->crawl_sitemap_recursive((string) $value->loc));
        }
        return $urls;
    }
}
