<?php

namespace Hybrid_Optimize\I18n;

class I18n
{
    public function textdomain()
    {

        load_plugin_textdomain(
            'hybrid-optimize',
            false,
            dirname(dirname(plugin_basename(__FILE__))) . '/languages/'
        );
    }
}
