<?php

namespace Hybrid_Optimize\Deactivator;

use Hybrid_Optimize\Cache\Purge;
use Hybrid_Optimize\Helper\Helper;

class Deactivator
{
    public function deactivate()
    {
        $this->remove_wp_cache_constant();

        $this->remove_advanced_cache();

        $this->remove_htaccess_rules();

        Purge::get_instance()->cache_flush();
    }

    public function remove_wp_cache_constant()
    {
        $wp_config_file = Helper::setup_wp_filesystem()->abspath() . 'wp-config.php';

        if (!is_file($wp_config_file)) {
            $wp_config_file = Helper::setup_wp_filesystem()->touch($wp_config_file);
        }

        if (!is_file($wp_config_file) || !is_writable($wp_config_file)) {
            return;
        }

        $content = "\ndefine('WP_CACHE', true); // Added by Hybrid Optimize";

        $wp_config = file_get_contents($wp_config_file);

        $wp_config = str_replace($content, '', $wp_config);

        file_put_contents($wp_config_file, $wp_config);
    }

    public function remove_advanced_cache()
    {
        @unlink(WP_CONTENT_DIR . '/advanced-cache.php');
    }

    public function remove_htaccess_rules()
    {
        $htaccess_file = Helper::setup_wp_filesystem()->abspath() . '.htaccess';

        if (!is_readable($htaccess_file) || !is_writeable($htaccess_file)) {
            return;
        }

        $htaccess_contents = file_get_contents($htaccess_file);

        $htaccess_contents = ltrim(
            preg_replace(
                '/\s*# BEGIN Hybrid Optimize.*# END Hybrid Optimize\s*?/isU',
                PHP_EOL . PHP_EOL,
                $htaccess_contents
            )
        );

        file_put_contents($htaccess_file, $htaccess_contents);
    }
}
