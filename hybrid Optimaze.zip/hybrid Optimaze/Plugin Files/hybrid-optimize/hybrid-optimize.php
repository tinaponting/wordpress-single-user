<?php
/**
 * Plugin Name:       Hybrid Optimize
 * Description:       Next-Gen Optimizer for WordPress
 * Version:           1.0.4
 * Text Domain:       hybrid-optimize
 * Domain Path:       /languages
 */

use Hybrid_Optimize\Loader\Loader;
use Hybrid_Optimize\Activator\Activator;
use Hybrid_Optimize\Deactivator\Deactivator;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define Constants.
$host = parse_url(get_home_url(), PHP_URL_HOST);
define('HYBRID_OPTIMIZE_DEV', true);
define('HYBRID_OPTIMIZE_VERSION', '1.0.4');
define('HYBRID_OPTIMIZE_SLUG', 'hybrid-optimize');
define('HYBRID_OPTIMIZE_FILE', __FILE__);
define('HYBRID_OPTIMIZE_URL', plugin_dir_url(__FILE__));
define('HYBRID_OPTIMIZE_DIR', plugin_dir_path(__FILE__));
define('HYBRID_OPTIMIZE_CACHE_DIR', WP_CONTENT_DIR . "/uploads/hybrid-optimize/$host/");
define('HYBRID_OPTIMIZE_CACHE_URL', WP_CONTENT_URL . "/uploads/hybrid-optimize/$host/");
define('HYBRID_OPTIMIZE_API_URL', 'https://api.xxxxx.com');

require_once HYBRID_OPTIMIZE_DIR . '/vendor/vendorloader.php';
require_once HYBRID_OPTIMIZE_DIR . '/includes/autoloader.php';

\Hybrid_Optimize\Autoloader::getInstance()->register();
\Hybrid_Optimize\Autoloader::getInstance()->addNamespace(
    'Hybrid_Optimize',
    realpath(HYBRID_OPTIMIZE_DIR . '/includes')
);

register_activation_hook(__FILE__, [new Activator(), 'activate']);
register_deactivation_hook(__FILE__, [new Deactivator(), 'deactivate']);

// Initialize the loader.
new Loader();
