Read me! - Important:

Set right to file: config.php 444 
and nobody can write to your files!